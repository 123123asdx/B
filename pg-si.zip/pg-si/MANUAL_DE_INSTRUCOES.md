# Manual de instruções — Panda Gótico, PoC Copilot e ARTEX

Este manual explica como usar as ferramentas desta pasta, do início ao fim, com os comandos exatos.

Pasta de trabalho (Windows): `C:\Users\pedroso\Downloads\pg-si`

---

## 1. Visão geral

| Ferramenta | O que faz | Quando usar |
|---|---|---|
| `panda_gotico.py` | Hub interativo: catálogo de apps/planos/modelos, grava o `.env`, arranca a PoC e valida | **Ponto de partida** |
| `poc.py` | Ponte: transforma a subscrição GitHub Copilot numa API OpenAI-compatível em `http://…:4141/v1` | Arrancado pelo hub, ou à mão |
| `artex-traduzido.bat` | Abre a UI do ARTEX (8790 / tradutor) | Para trabalhar com o modelo escolhido |
| `artex-copilot-8788.bat` | Instância ARTEX isolada na porta 8788 | Se não quiseres mexer na instância 8787 |
| `GUIA_ARTEX_COPILOT.md` | Guia detalhado com diagnósticos | Quando algo falha |

### Como as peças se ligam

```
 Hub (panda_gotico.py)
   │ grava .env e arranca
   ▼
 poc.py serve :4141  ──► API Copilot (GitHub)
   ▲
   │ Base URL = http://host.docker.internal:4141/v1
 ARTEX (Docker, UI em http://localhost:8787 ou 8790)
```

- O **ARTEX** corre em Docker. Dentro do container, `127.0.0.1` é o próprio container, por isso o perfil **tem de** usar `host.docker.internal`.
- A **PoC** tem de escutar em `0.0.0.0` para o container a alcançar. O hub faz isto sozinho quando deteta Docker.

---

## 2. Requisitos

- Python 3.9 ou superior (só biblioteca padrão, não há `pip install`).
- Conta GitHub com **Copilot Pro** ou **Pro+** (compra feita no app iOS).
- Docker Desktop a correr (para o ARTEX).
- Os ficheiros na mesma pasta: `panda_gotico.py` e `poc.py`.

Verificar Python:

```powershell
python --version
```

---

## 3. Primeiro uso (passo a passo)

### Passo 1 — Abrir o hub

```powershell
cd C:\Users\pedroso\Downloads\pg-si
python panda_gotico.py
```

### Passo 2 — Escolher o app e o plano

No menu principal, escreve o número do app (ex.: `1` para GitHub Copilot). Depois escolhe o plano (`1` Pro ou `2` Pro+) e o modelo:

| Modelo | Custo | Nota |
|---|---|---|
| `gpt-6-luna` | 1× créditos | **recomendado** para o ARTEX |
| `claude-haiku-5.5` | 1× créditos | tool use forte |
| `claude-sonnet-5.5` | 20× créditos | caro; só tarefas difíceis |

### Passo 3 — Executar tudo

No menu do app, escreve `1`:

```
[1] EXECUTAR TUDO (login 1ª vez + PoC + validar + endereço ARTEX)
```

O que acontece, por ordem:

1. Grava o `.env` na pasta do hub (se faltar ou estiver diferente).
2. Se for a **primeira vez**, abre o login do GitHub (device flow): aparece um código, abres o link, colas o código e autorizas. Só acontece uma vez.
3. Arranca a PoC **desanexada** (sobrevive a fechar o hub), escutando em `0.0.0.0:4141` se detetar Docker.
4. Valida `/v1/models` com a chave do modelo.
5. Mostra o endereço e os valores para o perfil do ARTEX.

Saída típica de sucesso:

```
  PoC vai escutar em 0.0.0.0:4141  (detetado Docker)
  ✔ PoC no ar
  ✔ modelo 'claude-haiku-5.5' disponível (51 no catálogo)
  ✔ PoC validada.

  ▶ ENDEREÇO PARA O ARTEX
     Format:       OpenAI (Chat Completions)
     Base URL:     http://host.docker.internal:4141/v1
     Model:        claude-haiku-5.5
     API Key:      sk-poc-claude-haiku-5-5-…
```

### Passo 4 — Criar o perfil no ARTEX

1. Abre a UI do ARTEX (`http://localhost:8787` ou `8790`).
2. Vai a **Configurações → LLM → New profile**.
3. Preenche com os valores do bloco "ENDEREÇO PARA O ARTEX":

| Campo | Valor |
|---|---|
| Name | `copilot-haiku` (ou `copilot-luna`, etc.) |
| Format | `OpenAI (Chat Completions)` |
| Base URL | `http://host.docker.internal:4141/v1` |
| Model | o modelo escolhido |
| API Key | a chave **desse** modelo |

4. **Test** → **Save** → **Activate**.

> **Regra:** cada modelo tem a **sua** chave. O ARTEX recusa chaves repetidas (`já está adicionada`). Para ver todas: `python poc.py keys`.

### Passo 5 — Confirmar

```powershell
curl.exe --noproxy "*" http://127.0.0.1:4141/health
curl.exe --noproxy "*" http://127.0.0.1:4141/v1/models
```

Usa sempre `curl.exe --noproxy "*"`. No PowerShell, `curl` é um alias que respeita o proxy do sistema e dá `connection timeout` sem motivo.

---

## 4. Referência do `panda_gotico.py`

### 4.1 Menus

**Menu principal**

```
[1..6] abrir o app           [D] duração       [A] ajuda iOS
[P] pesquisa                 [X] fora do script [S] parar PoC
[Q] sair
```

**Menu do app**

```
[1] EXECUTAR TUDO            [2] gravar .env (opcional)
[3] mostrar .env             [4] FAQ/manual
[S] parar a PoC              [V] voltar
```

### 4.2 Linha de comandos

| Comando | Faz |
|---|---|
| `python panda_gotico.py` | menu interativo |
| `python panda_gotico.py --list` | ranking em texto |
| `python panda_gotico.py --duracao` | horas por plano (6 workers × 2 tarefas) |
| `python panda_gotico.py --ios` | custos IAP na App Store |
| `python panda_gotico.py --fontes` | projetos de pesquisa |
| `python panda_gotico.py --excluidas` | apps fora do script (> $40) |
| `python panda_gotico.py --ids` | lista os ids dos apps |
| `python panda_gotico.py --provider github` | detalhe de um app |
| `python panda_gotico.py --env github --model gpt-6-luna` | mostra o `.env` |
| `python panda_gotico.py --auto github --model gpt-6-luna --yes` | grava `.env`, sobe a PoC e valida, sem perguntar |
| `python panda_gotico.py --stop` | para a PoC lançada pelo hub e liberta a 4141 |
| `python panda_gotico.py --env-path C:\caminho\.env` | grava o `.env noutro sítio |
| `python panda_gotico.py --poc-host 0.0.0.0` | força a PoC a escutar em todas as interfaces (Docker) |
| `python panda_gotico.py --poc-host 127.0.0.1` | só nesta máquina |
| `python panda_gotico.py --print` | sem cores (útil em logs) |
| `python panda_gotico.py --workload pesado` | `leve` / `medio` / `pesado` nos cálculos de duração |

> `--poc-host` por omissão é `auto`: se o Docker estiver a correr, usa `0.0.0.0`; senão, `127.0.0.1`.

### 4.3 Ficheiros que o hub cria ou lê

| Ficheiro | Conteúdo |
|---|---|
| `.env` (pasta do hub) | bloco `ARTEX_LLM_*` e `OPENAI_API_KEY` |
| `poc.pid` | pid da PoC lançada pelo hub (usado por `--stop`) |
| `poc.log` | log da PoC lançada pelo hub |
| `~/.config/copilot-poc/token.json` | token GitHub (chmod 600) |
| `~/.config/copilot-poc/keys.json` | uma chave local por modelo |

---

## 5. Referência do `poc.py`

Sintaxe: `python poc.py <comando> [opções]`

| Comando | Faz | Quando |
|---|---|---|
| `login` | device flow no GitHub; guarda o token | 1ª vez, ou se o token expirar |
| `whoami` | mostra plano e quota da conta | confirmar que a subscrição está ativa |
| `models` | lista os modelos disponíveis | ver que modelos existem |
| `keys` | mostra/gera uma chave por modelo | antes de criar perfis no ARTEX |
| `ask "pergunta" -m gpt-6-luna` | pergunta one-shot | testar sem ARTEX |
| `serve` | sobe o `/v1` falso | o uso normal |

### 5.1 `serve` — opções

| Opção | Por omissão | Significado |
|---|---|---|
| `--host` | `127.0.0.1` | interface de escuta. Para Docker: `0.0.0.0` |
| `--port` | `4141` | porta |
| `--api-key` | (chaves de `keys.json`) | chave(s) aceites, separadas por vírgula. Se for usada, o modo passa a ser **estrito** |
| `--initiator` | `user` | `user` ou `agent` (cabeçalho enviado ao Copilot) |
| `--upstream-base` | automático | força outro endpoint upstream |
| `--upstream-key` | automático | força outra chave upstream |
| `--upstream-model` | nenhum | força o nome do modelo enviado upstream |

Exemplos:

```powershell
python poc.py serve --host 0.0.0.0 --port 4141          # Docker
python poc.py serve --host 127.0.0.1 --port 4141        # só esta máquina
python poc.py serve --host 0.0.0.0 --api-key minha-chave
```

Ao arrancar, a PoC escreve o endereço para cada uso:

```
[+] /v1 falso a ouvir em 0.0.0.0:4141 (todas as interfaces)
    mesmo PC:   http://127.0.0.1:4141/v1
    Docker:     http://host.docker.internal:4141/v1   <- usa ESTE no perfil do ARTEX
[+] auth local activa: 3 chave(s) aceite(s) — uma por modelo
```

### 5.2 Endpoints que a PoC expõe

| Método | Caminho | Notas |
|---|---|---|
| GET | `/health` | público; confirma que está viva |
| GET | `/v1/models` | público |
| POST | `/v1/chat/completions` | formato Chat Completions (**usar este no ARTEX**) |
| POST | `/v1/responses` | formato Responses API (traduzido automaticamente) |
| GET | `/` | página inicial em HTML |

Autenticação: `Authorization: Bearer <chave>` ou `x-api-key: <chave>`. Cada modelo tem a sua chave. Um pedido sem chave válida recebe `401`.

Modelos que o Copilot só aceita em `/responses` (ex.: `gpt-6-luna`) são **reencaminhados automaticamente** e a decisão fica memorizada. Não precisas de fazer nada.

---

## 6. Referência do `.bat`

### 6.1 `artex-traduzido.bat`

Abre a UI do ARTEX (tradutor, 8790) com o modelo selecionado. Usa o `.env` que o hub gerou. Não usa a API por omissão da pasta do ARTEX.

Execução: duplo clique, ou:

```powershell
.\artex-traduzido.bat
```

### 6.2 `artex-copilot-8788.bat`

Instância **isolada** do ARTEX na porta **8788**, para não mexer na 8787 (que usa o DeepSeek).

- Lê o `.env` de `C:\artex-copilot`.
- Força as quatro chaves do Copilot.
- Arranca `artex.exe -addr :8788`.
- Arranca o `artex-proxy.py` na 8790.
- Abre o browser.

Requisito: a pasta `C:\artex-copilot` tem de existir, com o `.env` do hub copiado para lá.

---

## 7. Portas

| Porta | Quem | Para quê |
|---|---|---|
| 4141 | `poc.py` | API Copilot falsa (OpenAI-compatível) |
| 8787 | ARTEX (instância original) | UI com DeepSeek |
| 8788 | ARTEX isolado (`artex-copilot-8788.bat`) | UI com Copilot |
| 8790 | tradutor (`artex-proxy.py`) | UI traduzida |

Ver quem está numa porta:

```powershell
netstat -ano | findstr :4141
tasklist /FI "PID eq <PID>"
```

---

## 8. Operações do dia a dia

| Tarefa | Comando |
|---|---|
| Arrancar tudo | `python panda_gotico.py` → app → `1` |
| Parar a PoC | `python panda_gotico.py --stop` (ou `[S]` no menu) |
| Ver chaves | `python poc.py keys` |
| Ver conta e quota | `python poc.py whoami` |
| Ver modelos | `python poc.py models` |
| Testar um pedido | `python poc.py ask "olá" -m gpt-6-luna` |
| Nova conta GitHub | apagar `~/.config/copilot-poc/token.json` e correr `python poc.py login` |
| Novo perfil de modelo | `python poc.py keys` (gera a chave) → criar perfil na UI |

---

## 9. Diagnóstico rápido

| Sintoma | Causa provável | Solução |
|---|---|---|
| `tcp refused` / `connection refused` | nada na 4141 | `python panda_gotico.py --stop`, depois correr de novo |
| `connection timeout` no Test do ARTEX | Base URL com `127.0.0.1` dentro do Docker | usar `http://host.docker.internal:4141/v1` |
| `curl : Não é possível estabelecer ligação` | alias do PowerShell + proxy | `curl.exe --noproxy "*" …` |
| `porta 4141 ocupada, mas /health não responde` | processo antigo na 4141 | `netstat -ano \| findstr :4141` e `taskkill /PID <pid> /F` |
| `401 invalid api key` | chave de outro modelo | usar a chave do modelo (`python poc.py keys`) |
| `API key já está adicionada` | a mesma chave em dois perfis | cada modelo com a sua chave |
| `rota desconhecida: /v1/responses` | Format = `OpenAI (Responses API)` | mudar para `OpenAI (Chat Completions)` |
| `unsupported_api_for_model` | modelo só aceita `/responses` | usar o `poc.py` atual (reencaminha automaticamente) |
| `rota desconhecida: /v1` | `poc.py` antigo | substituir pelo novo |
| Hub: `endpoint ainda não validado` | PoC não respondeu | ver `netstat`, correr `--stop` e voltar a tentar |
| Hub: `porta ocupada, /health não responde` com PoC viva | proxy do Windows a interceptar `127.0.0.1` | já corrigido no hub; alternativa: `set NO_PROXY=127.0.0.1,localhost` |
| `(sem Docker detetado)` com ARTEX em Docker | deteção falhou | `python panda_gotico.py --poc-host 0.0.0.0` |
| Traceback ao sair com Ctrl+C | versão antiga do hub | copiar o `panda_gotico.py` atual |
| `model "X" not found` / modelo ausente | conta sem esse modelo | `python poc.py models` |
| Token expirado / 401 do Copilot | token caducou | `python poc.py login` |

---

## 10. Segurança

- **Não partilhes** o `token.json`, o `keys.json` nem o `.env`: dão acesso à tua conta e à PoC.
- A PoC em `0.0.0.0` fica acessível a **toda a rede local**. Usa-a só em redes de confiança, ou usa `127.0.0.1` se o ARTEX correr nativo.
- O uso da subscrição do Copilot como API **não é suportado pelo GitHub** (risco de suspensão da conta). Ver o campo "ToS" no hub.
- Se alguma chave DeepSeek (`sk-d7ef…`) ou password de Postgres apareceu em capturas ou logs, **roda-as** no provedor e no `.env`.

---

## 11. Glossário

- **Device flow** — login no GitHub em que copias um código para `github.com/login/device`.
- **Format** — campo do perfil do ARTEX que escolhe o dialeto da API: `Anthropic`, `OpenAI (Chat Completions)` ou `OpenAI (Responses API)`.
- **Base URL** — endereço onde o ARTEX envia pedidos (aqui, a PoC).
- **Perfil** — conjunto de Format + Base URL + Model + API Key guardado no ARTEX.
- **Credits** — unidade de consumo da subscrição Copilot (1 crédito = US$ 0,01).
- **host.docker.internal** — nome que um container Docker usa para chegar ao Windows.
