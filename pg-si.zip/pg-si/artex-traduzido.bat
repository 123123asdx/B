@echo off
rem ============================================================
rem  ARTEX — iniciar traducao (proxy) e abrir o browser
rem  Pode ficar em qualquer pasta: os caminhos sao absolutos.
rem ============================================================
setlocal

set "PY=%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe"
set "PROXY=C:\Users\pedroso\Documents\deepseek-harness\default-workspace\artex-setup\artex-proxy.py"

if not exist "%PY%" (
  echo [x] Python do DSH nao encontrado:
  echo     %PY%
  pause
  exit /b 1
)

if not exist "%PROXY%" (
  echo [x] Proxy nao encontrado:
  echo     %PROXY%
  pause
  exit /b 1
)

echo ARTEX — traducao
echo   proxy: %PROXY%
echo   abre:  http://localhost:8790
echo.
echo Deixa esta janela aberta. Fechar a janela para o proxy.
echo.

start "" cmd /c "timeout /t 3 >nul & start http://localhost:8790"
"%PY%" "%PROXY%"

echo.
echo [proxy encerrado]
pause
