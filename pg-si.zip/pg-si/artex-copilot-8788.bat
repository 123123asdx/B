@echo off
setlocal EnableExtensions
rem ============================================================
rem  ARTEX Copilot - instancia nova (8788) + tradutor (8790)
rem
rem  O que faz:
rem   1) usa a pasta C:\artex-copilot (copia da pasta original)
rem   2) le o .env dessa pasta (mantem ARTEX_PG_DSN e o resto)
rem   3) forca o LLM para a PoC do Copilot (127.0.0.1:4141)
rem   4) arranca o ARTEX na porta 8788  (a 8787 fica com o DeepSeek)
rem   5) arranca o tradutor na 8790 e abre o browser
rem
rem  ANTES DE CORRER (1 vez):
rem   - copia a pasta do ARTEX para C:\artex-copilot
rem   - no .env dessa pasta poe (ou corre o hub com
rem     --env-path C:\artex-copilot\.env):
rem       ARTEX_LLM_PROVIDER=openai
rem       ARTEX_LLM_BASE_URL=http://127.0.0.1:4141/v1
rem       ARTEX_LLM_MODEL=gpt-6-luna
rem       OPENAI_API_KEY=dummy
rem   - no artex-proxy.py o alvo tem de ser http://127.0.0.1:8788
rem ============================================================

rem ---------- caminhos: edita so aqui ----------
set "ARTEX_DIR=C:\artex-copilot"
set "ARTEX_EXE=%ARTEX_DIR%\artex.exe"
set "PROXY=C:\Users\pedroso\Documents\deepseek-harness\default-workspace\artex-setup\artex-proxy.py"
set "PY=python"
set "PORT=8788"
set "PROXY_PORT=8790"

if not exist "%ARTEX_DIR%" mkdir "%ARTEX_DIR%" >nul 2>&1
if not exist "%ARTEX_EXE%" (
  echo [x] Nao encontrei "%ARTEX_EXE%"
  echo     Copia a pasta do ARTEX para "%ARTEX_DIR%" ou edita ARTEX_EXE.
  pause
  exit /b 1
)
if not exist "%PROXY%" (
  echo [x] Nao encontrei "%PROXY%"
  echo     Edita a variavel PROXY neste .bat.
  pause
  exit /b 1
)

rem ---------- 1) carrega o .env da instancia nova ----------
rem  Mantem ARTEX_PG_DSN, ARTEX_CONFIG, etc. As 4 chaves do LLM
rem  sao reescritas logo abaixo, por isso o DeepSeek nao entra.
if exist "%ARTEX_DIR%\.env" (
  for /f "usebackq eol=# tokens=1,* delims==" %%a in ("%ARTEX_DIR%\.env") do set "%%a=%%b"
)

rem ---------- 2) forca o LLM para o Copilot ----------
set "ARTEX_LLM_PROVIDER=openai"
set "ARTEX_LLM_BASE_URL=http://127.0.0.1:4141/v1"
set "ARTEX_LLM_MODEL=gpt-6-luna"
set "OPENAI_API_KEY=dummy"

rem  Alguns proxies leem uma destas; nao faz mal se ignorarem.
set "ARTEX_URL=http://127.0.0.1:%PORT%"
set "ARTEX_TARGET=http://127.0.0.1:%PORT%"
set "TARGET=http://127.0.0.1:%PORT%"

rem ---------- 3) a PoC esta viva? ----------
powershell -NoProfile -Command "try { Invoke-WebRequest -UseBasicParsing 'http://127.0.0.1:4141/health' -TimeoutSec 2 | Out-Null; exit 0 } catch { exit 1 }" >nul 2>&1
if errorlevel 1 (
  echo [!] A PoC nao responde em http://127.0.0.1:4141
  echo     Noutra janela:  python poc.py serve --port 4141
  echo.
)

rem ---------- 4) ARTEX novo na 8788 ----------
echo [*] ARTEX Copilot  -> http://localhost:%PORT%
start "ARTEX Copilot %PORT%" /D "%ARTEX_DIR%" "%ARTEX_EXE%" -addr :%PORT%

rem ---------- 5) tradutor na 8790 ----------
echo [*] Tradutor       -> http://localhost:%PROXY_PORT%
start "ARTEX Tradutor %PROXY_PORT%" "%PY%" "%PROXY%"

rem ---------- 6) abre o browser ----------
timeout /t 4 >nul
start "" "http://localhost:%PROXY_PORT%"

echo.
echo ============================================================
echo   ARTEX Copilot : http://localhost:%PORT%
echo   Tradutor      : http://localhost:%PROXY_PORT%
echo   PoC           : http://127.0.0.1:4141/v1
echo.
echo   O ARTEX antigo (8787 + .env DeepSeek) nao foi tocado.
echo   Se o tradutor ainda mostrar o DeepSeek, ve o aviso
echo   sobre "perfil ativo" na resposta do assistente.
echo ============================================================
echo.
pause
