#!/usr/bin/env python3
"""
fechar_porta.py - fecha portas TCP que estejam em LISTENING (equivalente Python
do fechar-porta.ps1).

Como funciona:
  1. Corre "netstat -ano -p TCP" e filtra as linhas em LISTENING na(s) porta(s).
  2. Identifica o PID dono do socket.
  3. Termina o processo (ctypes TerminateProcess, com recurso a taskkill).
  4. Confirma que o socket desapareceu, repetindo o kill se necessario.

Sem dependencias externas (nao precisa de psutil). Apenas Windows, porque usa
netstat -ano e a API Win32.

Uso:
    python fechar_porta.py                  # fecha a 4141 uma vez
    python fechar_porta.py --dry-run        # mostra quem esta la, sem matar
    python fechar_porta.py --port 4141 8080 # varias portas
    python fechar_porta.py --watch          # vigia e fecha sempre que reabrir

Codigos de saida:
    0 = porta fechada / nada a escutar
    1 = sobrou algo em LISTENING
    2 = erro de utilizacao
"""

from __future__ import annotations

import argparse
import ctypes
import os
import re
import subprocess
import sys
import time

DEFAULT_PORT = 4141
SYSTEM_PIDS = {0, 4}

# "  TCP    0.0.0.0:4141       0.0.0.0:0     LISTENING       636"
NETSTAT_RE = re.compile(r"^\s*TCP\s+(\S+):(\d+)\s+\S+\s+LISTENING\s+(\d+)\s*$")

PROCESS_TERMINATE = 0x0001
PROCESS_QUERY_LIMITED_INFORMATION = 0x1000

if os.name == "nt":
    _kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    _kernel32.OpenProcess.argtypes = [ctypes.c_ulong, ctypes.c_int, ctypes.c_ulong]
    _kernel32.OpenProcess.restype = ctypes.c_void_p
    _kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
    _kernel32.QueryFullProcessImageNameW.argtypes = [
        ctypes.c_void_p, ctypes.c_ulong, ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_ulong)
    ]
    _kernel32.TerminateProcess.argtypes = [ctypes.c_void_p, ctypes.c_uint]
else:
    _kernel32 = None


def _win_error() -> str:
    code = ctypes.get_last_error()
    return ctypes.FormatError(code).strip() if code else "erro desconhecido"


def listening_sockets(ports: list[int]) -> list[dict]:
    """Sockets TCP em LISTENING nas portas pedidas."""
    try:
        raw = subprocess.run(
            ["netstat", "-ano", "-p", "TCP"],
            capture_output=True, text=True, errors="replace", timeout=30,
        ).stdout
    except (OSError, subprocess.SubprocessError) as exc:
        print(f"[erro] nao consegui correr netstat: {exc}", file=sys.stderr)
        return []

    found = []
    for line in raw.splitlines():
        m = NETSTAT_RE.match(line)
        if not m:
            continue
        address, port, pid = m.group(1), int(m.group(2)), int(m.group(3))
        if port in ports:
            found.append({"port": port, "address": address, "pid": pid})
    return found


def process_name(pid: int) -> str:
    """Nome do executavel, via Win32; '?' se nao houver permissoes."""
    if pid == 0:
        return "<System Idle>"
    if pid == 4:
        return "<System>"
    if _kernel32 is None:
        return "?"

    handle = _kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, 0, pid)
    if not handle:
        return f"<sem acesso: {_win_error()}>"
    try:
        buf = ctypes.create_unicode_buffer(1024)
        size = ctypes.c_ulong(len(buf))
        if _kernel32.QueryFullProcessImageNameW(handle, 0, buf, ctypes.byref(size)):
            return os.path.basename(buf.value)
        return "?"
    finally:
        _kernel32.CloseHandle(handle)


def kill_pid(pid: int) -> tuple[bool, str]:
    """Termina o processo. Devolve (sucesso, mensagem de erro)."""
    if _kernel32 is not None:
        handle = _kernel32.OpenProcess(PROCESS_TERMINATE, 0, pid)
        if handle:
            try:
                if _kernel32.TerminateProcess(handle, 1):
                    return True, ""
                return False, _win_error()
            finally:
                _kernel32.CloseHandle(handle)
        win_err = _win_error()

    # Recurso: taskkill
    try:
        res = subprocess.run(
            ["taskkill", "/F", "/PID", str(pid)],
            capture_output=True, text=True, errors="replace", timeout=20,
        )
        if res.returncode == 0:
            return True, ""
        detail = (res.stderr or res.stdout or "").strip().splitlines()
        return False, detail[0] if detail else f"taskkill rc={res.returncode}"
    except (OSError, subprocess.SubprocessError) as exc:
        return False, str(exc)


def port_label(ports: list[int]) -> str:
    return ", ".join(f":{p}" for p in ports)


def close_once(ports: list[int], dry_run: bool = False) -> bool:
    """Uma passagem de fecho. Devolve True se no fim nada escuta."""
    targets = listening_sockets(ports)
    if not targets:
        print(f"[--] Nada a escutar em {port_label(ports)}")
        return True

    for t in targets:
        name = process_name(t["pid"])
        desc = f"porta {t['port']} em {t['address']} -> PID {t['pid']} ({name})"

        if t["pid"] in SYSTEM_PIDS:
            print(f"[!!] {desc} : processo de sistema, nao vou matar")
            continue

        if dry_run:
            print(f"[dry] mataria {desc}")
            continue

        ok, err = kill_pid(t["pid"])
        if ok:
            print(f"[ok] morto {desc}")
        else:
            print(f"[!!] falhou matar {desc} : {err}")

    if dry_run:
        return False

    # Espera o socket libertar-se, com novas tentativas se necessario.
    left = listening_sockets(ports)
    for rnd in range(1, 4):
        for _ in range(10):
            left = listening_sockets(ports)
            if not left:
                break
            time.sleep(0.3)
        if not left:
            break
        if rnd < 3:
            for s in left:
                if s["pid"] not in SYSTEM_PIDS:
                    kill_pid(s["pid"])
            time.sleep(0.5)

    left = listening_sockets(ports)
    if not left:
        print(f"[ok] porta(s) fechada(s): {port_label(ports)}")
        return True

    for s in left:
        print(f"[!!] ainda em LISTENING: porta {s['port']} em {s['address']} "
              f"-> PID {s['pid']} ({process_name(s['pid'])})")
    return False


def parse_args(argv: list[str]) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Fecha portas TCP em LISTENING matando o processo dono.",
        epilog="Exemplos: python fechar_porta.py | --dry-run | --port 4141 8080 | --watch",
    )
    p.add_argument("-p", "--port", nargs="+", type=int, default=[DEFAULT_PORT],
                   metavar="PORTA", help=f"porta(s) a fechar (omissao: {DEFAULT_PORT})")
    p.add_argument("--dry-run", action="store_true",
                   help="mostra o que seria morto, sem matar")
    p.add_argument("--watch", action="store_true",
                   help="fica em ciclo, fechando a porta sempre que reabrir")
    p.add_argument("--interval", type=int, default=5, metavar="SEG",
                   help="intervalo do --watch em segundos (omissao: 5)")
    ns = p.parse_args(argv)

    for port in ns.port:
        if not 1 <= port <= 65535:
            p.error(f"porta invalida: {port}")
    if ns.interval < 1:
        ns.interval = 1
    return ns


def main(argv: list[str] | None = None) -> int:
    # Sem isto, em modo --watch o output fica retido no buffer quando nao e um terminal.
    try:
        sys.stdout.reconfigure(line_buffering=True)
    except (AttributeError, ValueError):
        pass

    if os.name != "nt":
        print("[erro] este script usa a API Win32 e o netstat -ano: so corre em Windows.",
              file=sys.stderr)
        return 2

    args = parse_args(sys.argv[1:] if argv is None else argv)

    if args.watch:
        print(f"[..] a vigiar {port_label(args.port)} "
              f"(intervalo {args.interval}s) - Ctrl+C para parar")
        try:
            while True:
                close_once(args.port)
                time.sleep(args.interval)
        except KeyboardInterrupt:
            print("\n[..] parado")
            return 0

    close_once(args.port, dry_run=args.dry_run)
    if args.dry_run:
        return 0
    return 0 if not listening_sockets(args.port) else 1


if __name__ == "__main__":
    sys.exit(main())