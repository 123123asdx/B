#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PANDA GÓTICO — hub de IA para o ARTEX (v3)
==========================================

REGRA DE ENTRADA (rígida):
  só apps com 100% de certeza de estarem nos DOIS lugares:
    · iOS  -> subscrição com compra integrada (IAP)
    · Windows -> executar a PoC/proxy com a conta subscrita no iOS
  e só planos até US$ 40 (nada de US$ 50+).

Fluxo:
  1. escolhes o app no ranking
  2. escolhes o plano (Pro / Pro+ ...)
  3. escolhes o MODELO que vai para o .env do ARTEX
  4. o .env é mostrado/gravado
  5. vês detalhes e executas a PoC (proxy /v1)

Uso:
    python3 panda_gotico.py
    python3 panda_gotico.py --list
    python3 panda_gotico.py --print          # sem cores
    python3 panda_gotico.py --provider github
    python3 panda_gotico.py --env github --model gpt-6-luna
    python3 panda_gotico.py --duracao
    python3 panda_gotico.py --ios
    python3 panda_gotico.py --fontes
    python3 panda_gotico.py --excluidas
"""

import argparse
import json
import os
import re
import secrets
import shutil
import subprocess
import sys
import time
import unicodedata
import urllib.error
import urllib.request

# --------------------------------------------------------------------------- #
# Cores
# --------------------------------------------------------------------------- #
class C:
    R = "\033[0m"; B = "\033[1m"; D = "\033[2m"
    P = "\033[38;5;141m"; V = "\033[38;5;99m"
    G = "\033[38;5;114m"; Y = "\033[38;5;179m"; Rr = "\033[38;5;167m"
    Cy = "\033[38;5;116m"; Gr = "\033[38;5;245m"; W = "\033[97m"


_COLOR = sys.stdout.isatty() and os.environ.get("NO_COLOR") is None
WIDTH = 92
BASE = os.path.dirname(os.path.abspath(__file__))

# Interface onde a PoC escuta. 127.0.0.1 = só nesta máquina.
# Para o ARTEX em Docker usa 0.0.0.0 (e no perfil: host.docker.internal).
# "auto" = deteta containers a falar de artex e escolhe 0.0.0.0 se houver.
POC_HOST = "auto"


def _docker_cmd(args, timeout=4):
    try:
        return subprocess.run(["docker"] + args, capture_output=True,
                              text=True, timeout=timeout)
    except Exception:  # noqa: BLE001
        return None


def docker_ativo():
    """True se o daemon do Docker responde (não basta o exe existir)."""
    if not shutil.which("docker"):
        return False
    r = _docker_cmd(["info", "--format", "{{.ServerVersion}}"], timeout=5)
    return bool(r and r.returncode == 0 and (r.stdout or "").strip())


def detectar_docker():
    """True se parecer haver um ARTEX em Docker a correr nesta máquina."""
    if not shutil.which("docker"):
        return False
    out = _docker_cmd(["ps", "--format", "{{.Names}}"])
    if out is not None and out.returncode == 0:
        nomes = [l.strip().lower() for l in (out.stdout or "").splitlines()]
        if any("artex" in n for n in nomes):
            return True
    # não achou o container pelo nome: se o Docker está de pé, assume Docker
    # (um ARTEX parado também precisa de 0.0.0.0 quando arrancar)
    return docker_ativo()


def resolver_poc_host(escolhido):
    """Converte 'auto' em 127.0.0.1 ou 0.0.0.0."""
    if escolhido and escolhido != "auto":
        return escolhido
    return "0.0.0.0" if detectar_docker() else "127.0.0.1"


def porta_aberta(host="127.0.0.1", port=4141, timeout=0.6):
    import socket
    s = socket.socket()
    s.settimeout(timeout)
    try:
        s.connect((host, port))
        return True
    except OSError:
        return False
    finally:
        try:
            s.close()
        except OSError:
            pass


def c(code, *txt):
    s = "".join(str(t) for t in txt)
    return f"{code}{s}{C.R}" if _COLOR else s


def strip_codes(s):
    return re.sub(r"\033\[[0-9;]*m", "", s)


def w(s):
    return sum(2 if unicodedata.east_asian_width(ch) in "WF" else 1 for ch in strip_codes(s))


def cut(s, n):
    s = strip_codes(s)
    if w(s) <= n:
        return s
    out, acc = "", 0
    for ch in s:
        cw = 2 if unicodedata.east_asian_width(ch) in "WF" else 1
        if acc + cw > n - 1:
            break
        out += ch
        acc += cw
    return out + "…"


def pad(s, n, align="<"):
    gap = max(0, n - w(s))
    if align == ">":
        return " " * gap + s
    if align == "^":
        l = gap // 2
        return " " * l + s + " " * (gap - l)
    return s + " " * gap


def preco_txt(v):
    s = f"{v:.2f}".rstrip("0").rstrip(".")
    return f"${s}"


def red(v):
    return c(C.Rr, v)


# --------------------------------------------------------------------------- #
# Banner
# --------------------------------------------------------------------------- #
BANNER = r"""
   ██████╗  █████╗ ███╗   ██╗██████╗  █████╗
   ██╔══██╗██╔══██╗████╗  ██║██╔══██╗██╔══██╗
   ██████╔╝███████║██╔██╗ ██║██║  ██║███████║
   ██╔═══╝ ██╔══██║██║╚██╗██║██║  ██║██╔══██║
   ██║     ██║  ██║██║ ╚████║██████╔╝██║  ██║
   ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═══╝╚═════╝ ╚═╝  ╚═╝
        ██████╗  ██████╗ ████████╗██╗ ██████╗ ██████╗
       ██╔════╝ ██╔═══██╗╚══██╔══╝██║██╔════╝██╔═══██╗
       ██║  ███╗██║   ██║   ██║   ██║██║     ██║   ██║
       ██║   ██║██║   ██║   ██║   ██║██║     ██║   ██║
       ╚██████╔╝╚██████╔╝   ██║   ██║╚██████╗╚██████╔╝
        ╚═════╝  ╚═════╝    ╚═╝   ╚═╝ ╚═════╝ ╚═════╝
"""

PANDA = r"""
        ▄▄███████▄▄
     ▄████▀     ▀████▄
    ███▀  ██   ██  ▀███
   ███   ████ ████   ███
   ███    ▀▀   ▀▀    ███
    ███▄   ▄███▄   ▄███
     ▀████▄▄▄▄▄▄▄████▀
        ▀▀███████▀▀
"""


def banner():
    print()
    print(c(C.V, BANNER))
    for ln in PANDA.strip("\n").splitlines():
        print(c(C.Gr, "        " + ln))
    print(c(C.P, "  ✦ iOS IAP + Windows · 100% · planos até $40 · custo × tempo × ARTEX ✦"))
    print(c(C.Gr, "  " + "─" * 70))
    print()


# --------------------------------------------------------------------------- #
# Workload padrão: 6 workers × 2 tarefas; 1 execução = 2,0M in + 0,4M out; job 4h
# --------------------------------------------------------------------------- #
WORKLOADS = {"leve": 0.5, "medio": 1.0, "pesado": 2.0}
WORKLOADS_NOME = {"leve": "leve", "medio": "média", "pesado": "pesada"}

ENTITIES = [
    # ===================================================================== GitHub
    {
        "id": "github", "app": "GitHub Copilot",
        "ios": "IAP sim", "win": "sim", "certeza": 100,
        "conc": 10, "conf": 1.0,
        "via": "PoC /v1 (device flow + token exchange) — testado",
        "artex_base": "http://127.0.0.1:4141/v1",
        "projetos": "ericc-ch/copilot-api ★4.1k",
        "tos": "alto — usar subscrição como API não é suportado",
        "planos": [
            {"nome": "Pro", "preco": 10.0, "quota": "1.500 credits/mês",
             "horas": 12.5, "est": False, "nota": "entrada (~3 jobs)"},
            {"nome": "Pro+", "preco": 39.0, "quota": "7.000 credits/mês",
             "horas": 58.3, "est": False, "nota": "melhor custo/duração"},
        ],
        "modelos": [
            {"modelo": "gpt-6-luna", "rel": 1, "quota": "1× créditos",
             "nota": "recomendado p/ ARTEX"},
            {"modelo": "claude-haiku-5.5", "rel": 1, "quota": "1× créditos",
             "nota": "tool use forte"},
            {"modelo": "claude-sonnet-5.5", "rel": 20, "quota": "20× créditos",
             "nota": "caro; só tarefa difícil"},
        ],
        "exec": "poc",
        "faq": [
            ("O que acontece", [
                "A PoC faz device flow no GitHub, troca o token por um Copilot token",
                "e expõe http://127.0.0.1:4141/v1 para o ARTEX.",
            ]),
            ("Pré-requisitos", ["Conta GitHub com Copilot Pro/Pro+ comprado no app iOS."]),
            ("Passo a passo", [
                "1. App GitHub no iPhone → comprar Pro ou Pro+.",
                "2. Windows: python poc.py login",
                "3. python poc.py whoami  (confirma plano/quota)",
                "4. python poc.py serve --port 4141",
            ]),
            ("Limites", ["Credits acabam → 402/403.", "Sonnet queima 20× mais.", "Risco de ban."]),
        ],
    },
    # ===================================================================== Antigravity
    {
        "id": "antigravity", "app": "Google Antigravity",
        "ios": "IAP sim", "win": "sim", "certeza": 100,
        "conc": 3, "conf": 0.85,
        "via": "CLIProxyAPI / agy2api (OAuth Google)",
        "artex_base": "http://127.0.0.1:8317/v1",
        "projetos": "CLIProxyAPI ★57.5k · agy2api ★5.3k",
        "tos": "médio — interfaces internas / preview",
        "planos": [
            {"nome": "AI Pro", "preco": 19.99, "quota": "quota 5h + semanal",
             "horas": 68.8, "est": True, "nota": "serve Antigravity + Gemini CLI"},
        ],
        "modelos": [
            {"modelo": "gemini-3.5-flash", "rel": 1, "quota": "1×", "nota": "mais barato"},
            {"modelo": "gemini-3.0-pro", "rel": 5, "quota": "~5×", "nota": "raciocínio"},
            {"modelo": "claude-sonnet-4.5", "rel": 10, "quota": "~10×", "nota": "código forte"},
        ],
        "exec": "proxy",
        "faq": [
            ("O que acontece", [
                "O CLIProxyAPI autentica a conta Google (OAuth) e expõe /v1 local;",
                "o ARTEX fala com esse /v1. O Antigravity é o cliente que dá acesso.",
            ]),
            ("Pré-requisitos", ["Google AI Pro comprado no app Gemini (iOS).", "CLIProxyAPI no Windows."]),
            ("Passo a passo", ["1. Subir CLIProxyAPI.", "2. Login OAuth Google.",
                               "3. Apontar o ARTEX para o /v1 local."]),
            ("Limites", ["403/429 → quota ou bloqueio de TLS.", "Modelos Pro podem exigir plano superior."]),
        ],
    },
    # ===================================================================== Gemini CLI
    {
        "id": "gemini-cli", "app": "Google Gemini CLI",
        "ios": "IAP sim", "win": "sim", "certeza": 100,
        "conc": 3, "conf": 0.85,
        "via": "CLIProxyAPI / gemini-cli-proxy (OAuth)",
        "artex_base": "http://127.0.0.1:8317/v1",
        "projetos": "CLIProxyAPI ★57.5k · gemini-cli-proxy ★152",
        "tos": "médio — OAuth do CLI fora do cliente",
        "planos": [
            {"nome": "AI Plus", "preco": 4.99, "quota": "quota menor",
             "horas": 17.2, "est": True, "nota": "entrada (~1 job/sem)"},
            {"nome": "AI Pro", "preco": 19.99, "quota": "RPD/RPM alto",
             "horas": 68.8, "est": True, "nota": "melhor p/ 6 workers"},
        ],
        "modelos": [
            {"modelo": "gemini-3.5-flash", "rel": 1, "quota": "1×", "nota": "mais barato"},
            {"modelo": "gemini-3.0-pro", "rel": 5, "quota": "~5×", "nota": "raciocínio"},
        ],
        "exec": "proxy",
        "faq": [
            ("O que acontece", ["Gemini CLI OAuth → proxy OpenAI-compatible → ARTEX."]),
            ("Pré-requisitos", ["AI Plus ou AI Pro (IAP do app Gemini).", "Gemini CLI no Windows."]),
            ("Passo a passo", ["1. Gemini CLI login.", "2. Subir o proxy.", "3. Apontar o ARTEX."]),
            ("Limites", ["Cotas por modelo; 429 frequente em Pro."]),
        ],
    },
    # ===================================================================== Codex
    {
        "id": "codex", "app": "OpenAI Codex/ChatGPT",
        "ios": "IAP sim", "win": "sim", "certeza": 100,
        "conc": 3, "conf": 0.85,
        "via": "CLIProxyAPI / codex-lb (OAuth ChatGPT)",
        "artex_base": "http://127.0.0.1:8317/v1",
        "projetos": "CLIProxyAPI ★57.5k · codex-lb ★3.4k",
        "tos": "alto — OAuth de subscrição fora do cliente",
        "planos": [
            {"nome": "Plus", "preco": 20.0, "quota": "janela 5h + semanal",
             "horas": 51.6, "est": True, "nota": "~3 jobs/sem"},
        ],
        "modelos": [
            {"modelo": "codex-mini", "rel": 1, "quota": "1×", "nota": "mais barato"},
            {"modelo": "codex", "rel": 5, "quota": "~5×", "nota": "equilíbrio"},
            {"modelo": "codex-max", "rel": 20, "quota": "~20×", "nota": "só tarefa difícil"},
        ],
        "exec": "proxy",
        "faq": [
            ("O que acontece", ["OAuth do ChatGPT/Codex guardado localmente e exposto em /v1."]),
            ("Pré-requisitos", ["ChatGPT Plus comprado no app iOS.", "Codex CLI no Windows."]),
            ("Passo a passo", ["1. Instalar Codex CLI.", "2. Login OAuth.",
                               "3. CLIProxyAPI lê as credenciais e serve /v1."]),
            ("Limites", ["429 → janela 5h.", "Contas podem ser sinalizadas."]),
        ],
    },
    # ===================================================================== Claude Code
    {
        "id": "claude-code", "app": "Anthropic Claude Code",
        "ios": "IAP sim", "win": "sim", "certeza": 100,
        "conc": 3, "conf": 0.80,
        "via": "CLIProxyAPI / claude-code-proxy (OAuth Claude)",
        "artex_base": "http://127.0.0.1:8317/v1",
        "projetos": "claude-code-proxy ★3.8k · CLIProxyAPI ★57.5k",
        "tos": "explícito: OAuth fora do Claude Code é proibido",
        "planos": [
            {"nome": "Pro", "preco": 20.0, "quota": "5h + semanal",
             "horas": 51.6, "est": True, "nota": "~3 jobs/sem"},
        ],
        "modelos": [
            {"modelo": "claude-haiku-5.5", "rel": 1, "quota": "1×", "nota": "mais barato"},
            {"modelo": "claude-sonnet-5.5", "rel": 5, "quota": "~5×", "nota": "equilíbrio"},
        ],
        "exec": "proxy",
        "faq": [
            ("O que acontece", ["OAuth do Claude Code → proxy converte para OpenAI → ARTEX."]),
            ("Pré-requisitos", ["Claude Pro comprado no app iOS.", "Claude Code no Windows."]),
            ("Passo a passo", ["1. Claude Code login.", "2. Proxy lê as credenciais.",
                               "3. /v1 local no ARTEX."]),
            ("Limites", ["Anthropic pode banir por uso de OAuth fora do cliente.", "429 por janela."]),
        ],
    },
    # ===================================================================== Grok
    {
        "id": "grok", "app": "xAI Grok Build",
        "ios": "IAP sim", "win": "sim", "certeza": 100,
        "conc": 3, "conf": 0.75,
        "via": "CLIProxyAPI / AIClient2API (OAuth/Cookie)",
        "artex_base": "http://127.0.0.1:8317/v1",
        "projetos": "CLIProxyAPI ★57.5k · AIClient2API ★9k",
        "tos": "alto — bypass de TLS fingerprint",
        "planos": [
            {"nome": "SuperGrok", "preco": 30.0, "quota": "quota/conta",
             "horas": 68.8, "est": True, "nota": "~4 jobs/sem"},
        ],
        "modelos": [
            {"modelo": "grok-4-fast", "rel": 1, "quota": "1×", "nota": "mais barato"},
            {"modelo": "grok-4", "rel": 4, "quota": "~4×", "nota": "equilíbrio"},
            {"modelo": "grok-4-heavy", "rel": 10, "quota": "~10×", "nota": "raciocínio"},
        ],
        "exec": "proxy",
        "faq": [
            ("O que acontece", ["OAuth do Grok CLI (ou cookie SSO) → /v1 compatível."]),
            ("Pré-requisitos", ["SuperGrok comprado no app iOS.", "Grok CLI + TLS sidecar."]),
            ("Passo a passo", ["1. Login no Grok CLI.", "2. Subir proxy com uTLS.",
                               "3. ARTEX → /v1 local."]),
            ("Limites", ["403 sem TLS sidecar.", "Sinalização de conta."]),
        ],
    },
]

# Fora do script (não cumprem 100% iOS+Windows e/ou plano ≤ $40)
EXCLUIDAS = [
    ("Z.ai · GLM Coding", "plano coding é comprado no site, não por IAP iOS"),
    ("Moonshot · Kimi Code", "vínculo IAP iOS → console/API não confirmado"),
    ("AWS · Kiro", "não tem app iOS (só IDE Windows)"),
    ("DeepSeek", "não tem app iOS nem IAP"),
    ("OpenRouter", "não tem app iOS/IAP"),
    ("MiniMax / Poe", "certeza <70% de ligar ao ARTEX"),
    ("Planos US$ 50+", "Max $99 · ChatGPT Pro $200 · Claude Max $124.99 · Gemini Ultra $199"),
]

FONTES = [
    ("Multi", "router-for-me/CLIProxyAPI", "★57.5k",
     "Antigravity, Codex, Claude Code, Gemini, Grok"),
    ("Multi", "justlovemaki/AIClient2API", "★9.0k",
     "Antigravity, Codex, Grok, Kiro, Gemini"),
    ("GitHub Copilot", "ericc-ch/copilot-api", "★4.1k", "Copilot → OpenAI/Anthropic"),
    ("Antigravity", "su-kaka/agy2api", "★5.3k", "Antigravity → OpenAI/Gemini/Claude"),
    ("Codex", "Soju06/codex-lb", "★3.4k", "Codex/ChatGPT load balancer"),
    ("Claude Code", "1rgs/claude-code-proxy", "★3.8k", "Claude Code → OpenAI"),
    ("Gemini CLI", "nettee/gemini-cli-proxy", "★152", "Gemini CLI → OpenAI"),
]

IOS_IAP = [
    ("GitHub", "Copilot Pro $10 · Pro+ $39", "SIM — PoC testada"),
    ("ChatGPT", "Plus $20", "SIM — via Codex OAuth"),
    ("Claude", "Pro $20", "SIM — via Claude Code OAuth (risco ToS)"),
    ("Gemini", "AI Plus $4.99 · AI Pro $19.99", "SIM — via Gemini CLI/Antigravity"),
    ("Grok", "SuperGrok $30", "SIM — via Grok CLI"),
]


# --------------------------------------------------------------------------- #
# Ranking
# --------------------------------------------------------------------------- #
def planos_visiveis(e):
    return sorted([p for p in e["planos"] if p["preco"] <= 40.0], key=lambda p: p["preco"])


def score_ent(e):
    best = 0.0
    for p in planos_visiveis(e):
        h_por_dolar = p["horas"] / p["preco"] if p["preco"] else 0.0
        s = h_por_dolar * min(e["conc"], 6) / 6.0 * e["conf"]
        best = max(best, s)
    return best


def ranking():
    return sorted([e for e in ENTITIES if e["certeza"] >= 100 and planos_visiveis(e)],
                  key=score_ent, reverse=True)


def find_ent(eid):
    return next((e for e in ENTITIES if e["id"] == eid), None)


def find_model(e, nome):
    return next((o for o in e["modelos"] if o["modelo"] == nome), None)


# --------------------------------------------------------------------------- #
# Render do ranking
# --------------------------------------------------------------------------- #
def render(wl="medio"):
    mult = WORKLOADS.get(wl, 1.0)
    rows = ranking()
    W = WIDTH
    print(c(C.P, "┌" + "─" * W + "┐"))
    t = f"RANKING · iOS IAP + Windows (100%) · planos até $40 · carga {WORKLOADS_NOME[wl]}"
    print(c(C.P, "│ ") + c(C.W + C.B, pad(t, W - 2)) + c(C.P, " │"))
    print(c(C.P, "╞" + "═" * W + "╡"))
    for i, e in enumerate(rows, 1):
        head = f"{i:02d} ▸ {e['app']}"
        meta = f"iOS: {e['ios']} · Windows: {e['win']} · {e['certeza']}% · conc {e['conc']}"
        print(c(C.P, "│ ") + c(C.P + C.B, pad(cut(head, 28), 28)) +
              c(C.G, pad(cut(meta, W - 30), W - 30)) + c(C.P, " │"))
        print(c(C.P, "│ ") + c(C.Gr, pad(cut("     via: " + e["via"], W - 2), W - 2)) + c(C.P, " │"))
        for p in planos_visiveis(e):
            h = p["horas"] * mult
            hpd = h / p["preco"] if p["preco"] else 0.0
            est = " (est.)" if p["est"] else ""
            linha = ("     " + pad(p["nome"], 9) + " " +
                     red(pad(preco_txt(p["preco"]) + "/mês", 11)) + " " +
                     pad(cut(p["quota"], 20), 20) + " " +
                     pad(f"~{h:.0f}h/mês{est}", 12) + " " +
                     pad(f"{hpd:.2f} h/$", 9))
            print(c(C.P, "│ ") + pad(linha, W - 2) + c(C.P, " │"))
        mods = " · ".join(m["modelo"] for m in e["modelos"])
        print(c(C.P, "│ ") + c(C.Gr, pad(cut("     modelos: " + mods, W - 2), W - 2)) + c(C.P, " │"))
        if i < len(rows):
            print(c(C.P, "├" + "─" * W + "┤"))
    print(c(C.P, "└" + "─" * W + "┘"))
    print(c(C.Gr, "  Ordem = índice (h/$ × concorrência/6 × confiança). Preços a vermelho são planos ≤ $40."))
    print(c(C.Gr, "  Horas estimadas para 6 workers × 2 tarefas (2M in + 0,4M out por execução, 4h/job). (est.) = quota não publicada."))
    print(c(C.Gr, "  O 1º modelo de cada app é o recomendado para o ARTEX; os seguintes gastam mais quota."))
    print()


# --------------------------------------------------------------------------- #
# Detalhe
# --------------------------------------------------------------------------- #
def detalhe(e):
    W = 78
    print(c(C.P, "╔" + "═" * W + "╗"))
    print(c(C.P, "║ ") + c(C.W + C.B, pad(cut(e["app"], W - 2), W - 2)) + c(C.P, " ║"))
    print(c(C.P, "╚" + "═" * W + "╝"))
    for k, v in (("iOS", e["ios"]), ("Windows", e["win"]), ("Certeza", f"{e['certeza']}%"),
                 ("Via", e["via"]), ("Projetos", e["projetos"]), ("ToS", e["tos"])):
        print("  " + c(C.Gr, pad(k + ":", 10)) + v)
    print()
    print(c(C.Gr, "  Planos ≤ $40:"))
    for p in planos_visiveis(e):
        est = " (est.)" if p["est"] else ""
        print("    " + c(C.W, pad(p["nome"], 10)) + red(pad(preco_txt(p["preco"]) + "/mês", 11)) +
              c(C.Gr, f"{p['quota']} · ~{p['horas']:.0f}h/mês{est} · {p['nota']}"))
    print()
    print(c(C.Gr, "  Modelos p/ o .env (mais barato → mais caro):"))
    for i, o in enumerate(e["modelos"], 1):
        tier = "$" if o["rel"] <= 2 else ("$$" if o["rel"] <= 6 else "$$$")
        print(f"    {i}. " + c(C.W, pad(o["modelo"], 24)) +
              c(C.Gr, f"{tier} {o['quota']} · {o['nota']}"))
    print()


def mostrar_faq(e):
    print(c(C.P, "╭─ FAQ / MANUAL · " + e["app"] + " " + "─" * max(0, 44 - len(e["app"])) + "╮"))
    for titulo, linhas in e["faq"]:
        print()
        print("  " + c(C.Y + C.B, "▸ " + titulo))
        for ln in linhas:
            print("    " + ln)
    print()
    print(c(C.P, "╰" + "─" * 70 + "╯"))
    print()


# --------------------------------------------------------------------------- #
# .env
# --------------------------------------------------------------------------- #
KEYS_FILE = os.path.join(os.path.expanduser("~"), ".config", "copilot-poc", "keys.json")


def _slug_modelo(modelo):
    s = re.sub(r"[^a-z0-9]+", "-", (modelo or "").lower()).strip("-")
    return s[:24] or "model"


def load_keys():
    try:
        with open(KEYS_FILE, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:  # noqa: BLE001
        return {}


def salvar_keys(d):
    try:
        os.makedirs(os.path.dirname(KEYS_FILE), exist_ok=True)
        with open(KEYS_FILE, "w", encoding="utf-8") as f:
            json.dump(d, f, indent=2, ensure_ascii=False)
        os.chmod(KEYS_FILE, 0o600)
    except Exception:  # noqa: BLE001
        pass


def chave_modelo(modelo):
    """Chave local estável e diferente para cada modelo (o ARTEX não repete keys)."""
    d = load_keys()
    k = d.get(modelo)
    if not k:
        k = "sk-poc-" + _slug_modelo(modelo) + "-" + secrets.token_hex(8)
        d[modelo] = k
        salvar_keys(d)
    return k


def base_artex(e):
    """Endereço que o ARTEX deve usar.

    Se a PoC escuta em 0.0.0.0 (Docker detetado), o container NÃO vê
    127.0.0.1 — tem de ser host.docker.internal. É esta a diferença entre
    "corri poc.py à mão com 0.0.0.0 e deu OK" e "o hub deu refused".
    """
    if e["exec"] == "poc" and POC_HOST == "0.0.0.0":
        return "http://host.docker.internal:4141/v1"
    return e["artex_base"]


def env_block(e, o):
    key = chave_modelo(o["modelo"]) if e["id"] == "github" else "<key-local-do-proxy>"
    return "\n".join([
        "ARTEX_LLM_PROVIDER=openai",
        f"ARTEX_LLM_BASE_URL={base_artex(e)}",
        f"ARTEX_LLM_MODEL={o['modelo']}",
        f"OPENAI_API_KEY={key}",
    ])


def salvar_env(txt, path=None):
    path = path or os.path.join(BASE, ".env")
    linhas = {}
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            for l in f:
                if "=" in l and not l.strip().startswith("#"):
                    k = l.split("=", 1)[0].strip()
                    linhas[k] = l.rstrip("\n")
    for l in txt.strip().splitlines():
        if "=" in l:
            linhas[l.split("=", 1)[0].strip()] = l
    with open(path, "w", encoding="utf-8") as f:
        for v in linhas.values():
            f.write(v + "\n")
    return path


def mostrar_env(e, o, prompt_save=True):
    txt = env_block(e, o)
    print(c(C.Cy, "╭─ .env DO ARTEX " + "─" * 60 + "╮"))
    for ln in txt.splitlines():
        if "=" in ln:
            kk, v = ln.split("=", 1)
            print("  " + c(C.Cy + C.B, kk + "=") + c(C.W + C.B, v))
        else:
            print("  " + c(C.W, ln))
    print(c(C.Cy, "╰" + "─" * 76 + "╯"))
    if prompt_save and input(c(C.Cy, "  gravar em .env? [s/N] ")).strip().lower() == "s":
        p = salvar_env(txt)
        print(c(C.G, f"  ✔ gravado em {p}"))
    return txt


# --------------------------------------------------------------------------- #
# Execução
# --------------------------------------------------------------------------- #
def executar(e, o):
    print(c(C.Cy + C.B, "  ▶ Execução"))
    if e["exec"] == "poc":
        poc = os.path.join(BASE, "poc.py")
        cmd = [sys.executable, poc, "serve", "--host", POC_HOST, "--port", "4141"]
        print(c(C.Gr, "  comando: " + " ".join(cmd)))
        if input(c(C.Cy, "  executar? [s/N] ")).strip().lower() == "s":
            if not os.path.exists(poc):
                print(c(C.Rr, "  ✖ poc.py não encontrado."))
                return
            p = subprocess.Popen(cmd)
            print(c(C.G, f"  ✔ PoC iniciada (pid {p.pid}) → {base_artex(e)}"))
        return
    # proxy OAuth
    binp = shutil.which("CLIProxyAPI") or shutil.which("cliproxyapi")
    if binp:
        print(c(C.Gr, f"  encontrado: {binp}"))
        if input(c(C.Cy, "  iniciar CLIProxyAPI? [s/N] ")).strip().lower() == "s":
            p = subprocess.Popen([binp])
            print(c(C.G, f"  ✔ proxy iniciado (pid {p.pid}) → {e['artex_base']}"))
        return
    print(c(C.Y, "  CLIProxyAPI não encontrado. Passos:"))
    print("    1. Descarrega em github.com/router-for-me/CLIProxyAPI/releases")
    print("    2. Corre: CLIProxyAPI")
    print("    3. Faz login OAuth no cliente (Codex/Claude/Gemini/Grok) uma vez")
    print(c(C.Gr, f"    4. O proxy expõe {e['artex_base']}"))
    print(c(C.Gr, "    (o .env acima já aponta para lá)"))


# --------------------------------------------------------------------------- #
# Modo automático: grava .env + sobe a PoC + valida o modelo
# --------------------------------------------------------------------------- #
_OPENER_LOCAL = [None]


def _opener_local():
    """Abre ligações locais SEM proxy.

    No Windows o urllib lê o proxy do registo (Internet Settings) e manda
    pedidos a 127.0.0.1 através dele. Num PC com Clash/V2Ray isso faz o
    /health e o /v1/models falharem mesmo com a PoC viva.
    """
    if _OPENER_LOCAL[0] is None:
        _OPENER_LOCAL[0] = urllib.request.build_opener(
            urllib.request.ProxyHandler({}))
    return _OPENER_LOCAL[0]


def _http_json(url, timeout=3.0, headers=None):
    req = urllib.request.Request(url, headers=headers or {})
    try:
        with _opener_local().open(req, timeout=timeout) as r:
            return r.status, json.loads(r.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode("utf-8", "replace"))
        except Exception:  # noqa: BLE001
            return e.code, None
    except Exception as e:  # noqa: BLE001
        return None, str(e)


def _root(base):
    b = base.rstrip("/")
    return b[:-3] if b.endswith("/v1") else b


def esperar_health(base, segundos=20):
    for _ in range(int(segundos * 2)):
        st, _ = _http_json(_root(base) + "/health", timeout=1.0)
        if st == 200:
            return True
        time.sleep(0.5)
    return False


def listar_modelos(base, key=None):
    h = {"Authorization": f"Bearer {key}", "x-api-key": key} if key else None
    st, data = _http_json(base.rstrip("/") + "/models", timeout=5.0, headers=h)
    if st == 401:
        return "401"
    if st != 200 or not isinstance(data, dict):
        return None
    return [m.get("id") for m in data.get("data", []) if m.get("id")]


def env_precisa(path, txt):
    if not os.path.exists(path):
        return True
    atual = {}
    with open(path, encoding="utf-8") as f:
        for l in f:
            if "=" in l and not l.strip().startswith("#"):
                k, v = l.rstrip("\n").split("=", 1)
                atual[k.strip()] = v.strip()
    for l in txt.splitlines():
        if "=" in l:
            k, v = l.split("=", 1)
            if atual.get(k.strip()) != v.strip():
                return True
    return False


def parar_poc():
    """Mata a PoC indicada em poc.pid (ou quem estiver na 4141)."""
    pidf = os.path.join(BASE, "poc.pid")
    pid = None
    try:
        pid = int(open(pidf, encoding="utf-8").read().strip())
    except Exception:  # noqa: BLE001
        pid = None
    if pid:
        try:
            if os.name == "nt":
                subprocess.run(["taskkill", "/PID", str(pid), "/F"],
                               capture_output=True)
            else:
                os.kill(pid, 15)
            print(c(C.G, f"  ✔ PoC (pid {pid}) terminada"))
        except Exception as e:  # noqa: BLE001
            print(c(C.Y, f"  ⚠ não consegui matar {pid}: {e}"))
        try:
            os.remove(pidf)
        except OSError:
            pass
    else:
        print(c(C.Y, "  ⚠ não há poc.pid (a PoC não foi lançada pelo hub)."))
    if porta_aberta("127.0.0.1", 4141):
        print(c(C.Y, "  ⚠ 4141 continua ocupada. Larga quem lá está:"))
        print("     Windows: netstat -ano | findstr :4141  →  taskkill /PID <pid> /F")
        print("     Linux:   ss -lntp | grep 4141")
    else:
        print(c(C.G, "  ✔ 4141 livre"))
    return 0


def auto_configurar(e, o, env_path=None, assume_yes=False, interactive=False):
    print(c(C.Cy + C.B, "  ▶ EXECUTAR TUDO: .env + login (1ª vez) + PoC + validação"))
    if e["exec"] == "poc":
        print(c(C.Gr, f"  PoC vai escutar em {POC_HOST}:4141"
                      + ("  (detetado Docker)" if POC_HOST == "0.0.0.0"
                         else "  (sem Docker detetado)")))
    path = env_path or os.path.join(BASE, ".env")
    txt = env_block(e, o)
    if env_precisa(path, txt):
        if not assume_yes:
            r = input(c(C.Cy, f"  gravar .env em {path}? [S/n] ")).strip().lower()
            if r in ("n", "nao", "não"):
                print(c(C.Gr, "  .env não alterado (podes gravar depois com [2])."))
                path = None
        if path:
            salvar_env(txt, path)
            print(c(C.G, f"  ✔ .env gravado: {path}"))
    else:
        print(c(C.G, f"  ✔ .env já estava correto: {path}"))

    if e["exec"] == "poc":
        tok = os.path.expanduser("~/.config/copilot-poc/token.json")
        if not os.path.exists(tok):
            if interactive and sys.stdin.isatty():
                print(c(C.Y, "  ⚠ primeira execução: device flow do GitHub (só uma vez)"))
                rc = subprocess.call([sys.executable, os.path.join(BASE, "poc.py"), "login"])
                if rc != 0 or not os.path.exists(tok):
                    print(c(C.Rr, "  ✖ login não concluído."))
                    return False
                print(c(C.G, "  ✔ conta guardada; não volta a pedir nas próximas execuções"))
            else:
                print(c(C.Y, "  ⚠ ainda não há token GitHub. Corre uma vez:"))
                print("     python3 poc.py login")
                print("     (depois escolhe [1] e ele já não pede mais)")
                return False
        else:
            print(c(C.G, "  ✔ conta já guardada (token em ~/.config/copilot-poc/token.json)"))
        if esperar_health(e["artex_base"], 1):
            print(c(C.G, "  ✔ PoC já está no ar"))
        elif porta_aberta("127.0.0.1", 4141):
            print(c(C.Y, "  ⚠ porta 4141 ocupada, mas /health não responde."))
            print(c(C.Gr, "     Provável processo antigo/zombi. Fecha-o e tenta outra vez:"))
            print(c(C.Gr, "     Windows: netstat -ano | findstr :4141  →  taskkill /PID <pid> /F"))
            return False
        else:
            log = os.path.join(BASE, "poc.log")
            cmd = [sys.executable, os.path.join(BASE, "poc.py"), "serve",
                   "--host", POC_HOST, "--port", "4141"]
            env = dict(os.environ)
            env["PYTHONUNBUFFERED"] = "1"
            # desanexa do terminal: Ctrl+C no hub NÃO mata a PoC
            kw = {}
            if os.name == "nt":
                kw["creationflags"] = 0x00000008 | 0x00000200  # DETACHED|NEW_GROUP
            else:
                kw["start_new_session"] = True
            with open(log, "w", encoding="utf-8") as f:
                proc = subprocess.Popen(cmd, stdout=f, stderr=subprocess.STDOUT,
                                        env=env, **kw)
            try:
                with open(os.path.join(BASE, "poc.pid"), "w", encoding="utf-8") as f:
                    f.write(str(proc.pid))
            except OSError:
                pass
            print(c(C.Gr, f"  … PoC iniciada (pid {proc.pid}); log: {log}"))
            print(c(C.Gr, f"     escuta em {POC_HOST}:4141 — sobrevive ao fechar o hub"))
            if esperar_health(e["artex_base"], 25):
                print(c(C.G, "  ✔ PoC no ar"))
            else:
                print(c(C.Rr, "  ✖ não respondeu em 25s. Últimas linhas do log:"))
                try:
                    print("".join(open(log, encoding="utf-8").readlines()[-8:]))
                except Exception:  # noqa: BLE001
                    pass
                return False
    else:
        binp = shutil.which("CLIProxyAPI") or shutil.which("cliproxyapi")
        if binp and not esperar_health(e["artex_base"], 1):
            subprocess.Popen([binp])
            print(c(C.Gr, f"  … {binp} iniciado"))
            if esperar_health(e["artex_base"], 25):
                print(c(C.G, "  ✔ proxy no ar"))
        elif not binp:
            print(c(C.Y, "  ⚠ CLIProxyAPI não instalado; o .env já aponta para o proxy."))

    chave = chave_modelo(o["modelo"]) if e["id"] == "github" else None
    ids = listar_modelos(e["artex_base"], chave)
    if ids == "401":
        print(c(C.Rr, "  ✖ /v1/models recusou a chave (401)."))
        print(c(C.Gr, "  A PoC está a correr com --api-key estrito; usa a chave do modelo:"))
        print("     " + (chave or "<chave>"))
        return False
    if ids is None:
        print(c(C.Y, "  ⚠ endpoint ainda não validado (a PoC não respondeu)."))
        if porta_aberta("127.0.0.1", 4141):
            print(c(C.Gr, "     A porta 4141 está aberta no host, mas a validação falhou."))
            print(c(C.Gr, "     O Test do ARTEX corre DENTRO do container → usa"))
            print(c(C.Gr, f"        http://host.docker.internal:4141/v1   (PoC em {POC_HOST})"))
        else:
            print(c(C.Rr, "     Nada a escutar em 127.0.0.1:4141 — a PoC não está a correr."))
            print(c(C.Gr, "     Sobe-a tu, numa janela própria (fica viva ao fechar o hub):"))
            print(c(C.Gr, f"        python poc.py serve --host {POC_HOST} --port 4141"))
        print(c(C.Gr, f"     Teste: {e['artex_base']}/models"))
        print(c(C.Gr, "     Se o comando acima funcionar à mão, o problema é o proxy"))
        print(c(C.Gr, "     do Windows a intercetar 127.0.0.1. Define:"))
        print(c(C.Gr, '        set NO_PROXY=127.0.0.1,localhost'))
        return False
    if o["modelo"] in ids:
        print(c(C.G, f"  ✔ modelo '{o['modelo']}' disponível ({len(ids)} no catálogo)"))
    else:
        print(c(C.Rr, f"  ✖ '{o['modelo']}' não está no catálogo. Disponíveis:"))
        print("     " + ", ".join(ids[:15]))
        print(c(C.Gr, "  Troca o ARTEX_LLM_MODEL por um destes."))
        return False
    print(c(C.G, "  ✔ PoC validada."))
    print()
    print(c(C.P + C.B, "  ▶ ENDEREÇO PARA O ARTEX"))
    print("     UI do ARTEX:  " + c(C.W, "http://localhost:8787") + c(C.Gr, "  (porta padrão; usa a tua)"))
    print("     Format:       " + c(C.W, "OpenAI (Chat Completions)")
          + c(C.Gr, "  ← não é 'OpenAI (Responses API)'"))
    print("     Base URL:     " + c(C.W, base_artex(e))
          + (c(C.Gr, "  ← usa ESTE no perfil do ARTEX (Docker)")
             if base_artex(e) != e["artex_base"] else ""))
    print("     mesmo PC:     " + c(C.W, e["artex_base"])
          + c(C.Gr, "  (só se o ARTEX correr nativo no Windows)"))
    if POC_HOST == "0.0.0.0":
        print("     Docker Linux: " + c(C.W, "http://172.17.0.1:4141/v1")
              + c(C.Gr, "  (ou o IP da máquina na LAN)"))
    else:
        print("     Docker:       " + c(C.W, "http://host.docker.internal:4141/v1")
              + c(C.Rr, "  ← mas a PoC só ouve em 127.0.0.1!"))
        print(c(C.Rr, "     Se o ARTEX corre em Docker, reinicia o hub com"))
        print(c(C.Rr, "     --poc-host 0.0.0.0 (senão o container não alcança a PoC)."))
    print("     Model:        " + c(C.W, o["modelo"]))
    print("     API Key:      " + c(C.W, chave_modelo(o["modelo"]) if e["id"] == "github"
                                    else "<key-local-do-proxy>")
          + c(C.Gr, "  ← chave DESTE modelo (uma por modelo)"))
    print(c(C.Gr, "     Configurações → LLM → New/Edit profile → Test → Save → Activate"))
    print(c(C.Gr, "     O campo no UI chama-se 'Format'; as opções são Anthropic /"))
    print(c(C.Gr, "     OpenAI (Chat Completions) / OpenAI (Responses API)."))
    print(c(C.Gr, "     Cada modelo tem a SUA chave (o ARTEX recusa keys repetidas)."))
    print(c(C.Gr, "     Ver todas:  python poc.py keys"))
    print()
    return True


# --------------------------------------------------------------------------- #
# Menus
# --------------------------------------------------------------------------- #
def escolher_plano(e):
    ps = planos_visiveis(e)
    if len(ps) == 1:
        p = ps[0]
        est = " (est.)" if p["est"] else ""
        print("  plano: " + c(C.W, p["nome"]) + " · " + red(preco_txt(p["preco"]) + "/mês") +
              c(C.Gr, f" · {p['quota']} · ~{p['horas']:.0f}h/mês{est}"))
        return p
    print(c(C.Gr, "  escolhe o plano (≤ $40):"))
    for i, p in enumerate(ps, 1):
        est = " (est.)" if p["est"] else ""
        print(f"   {i}. " + c(C.W, pad(p["nome"], 9)) + red(pad(preco_txt(p["preco"]) + "/mês", 11)) +
              c(C.Gr, f"{p['quota']} · ~{p['horas']:.0f}h/mês{est} · {p['nota']}"))
    op = input(c(C.Cy, "  plano> ")).strip()
    if op.isdigit() and 1 <= int(op) <= len(ps):
        return ps[int(op) - 1]
    return ps[0]


def escolher_modelo(e):
    print(c(C.Gr, "  escolhe o MODELO que vai no .env do ARTEX:"))
    for i, o in enumerate(e["modelos"], 1):
        tier = "$" if o["rel"] <= 2 else ("$$" if o["rel"] <= 6 else "$$$")
        print(f"   {i}. " + c(C.W, pad(o["modelo"], 24)) +
              c(C.Gr, f"{tier} {o['quota']} · {o['nota']}"))
    op = input(c(C.Cy, "  modelo> ")).strip()
    if op.isdigit() and 1 <= int(op) <= len(e["modelos"]):
        return e["modelos"][int(op) - 1]
    return e["modelos"][0]


def menu_ent(e):
    print()
    print(c(C.P + C.B, f"  ── {e['app']} · iOS IAP + Windows · 100% ──"))
    plano = escolher_plano(e)
    o = escolher_modelo(e)
    print()
    mostrar_env(e, o)
    print()
    detalhe(e)
    while True:
        print("   " + c(C.W, "[1]") + " EXECUTAR TUDO (login 1ª vez + PoC + validar + endereço ARTEX)")
        print("   " + c(C.W, "[2]") + " gravar .env (opcional, 1ª vez)   " +
              c(C.W, "[3]") + " mostrar .env   " + c(C.W, "[4]") + " FAQ/manual")
        print("   " + c(C.W, "[S]") + " parar a PoC (libertar a 4141)   " +
              c(C.W, "[V]") + " voltar")
        try:
            op = input(c(C.Cy, "  escolha> ")).strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            return
        if op == "1":
            try:
                auto_configurar(e, o, interactive=True)
            except KeyboardInterrupt:
                print(c(C.Y, "\n  ⚠ interrompido (a PoC, se já arrancou, fica viva)."))
        elif op == "2":
            mostrar_env(e, o)
        elif op == "3":
            mostrar_env(e, o, prompt_save=False)
        elif op == "4":
            mostrar_faq(e)
        elif op == "s":
            parar_poc()
        elif op in ("v", "", "voltar"):
            return


def tela_ios():
    print(c(C.P + C.B, "  AJUDA · custos de subscrição na App Store (planos ≤ $40)"))
    print(c(C.Gr, "  " + "─" * 86))
    for i, (app, preco, api) in enumerate(IOS_IAP, 1):
        print(f"  {i}. " + c(C.W, pad(app, 12)) + red(preco))
        print("     " + c(C.Gr, "└─ API? ") + c(C.G, api))
    print()
    print(c(C.Gr, "  Excluídos por preço (> $40): Max $99 · ChatGPT Pro $200 · Claude Max $124.99 · Gemini Ultra $199."))
    print()


def tela_fontes():
    print(c(C.P + C.B, "  PESQUISA · projetos que ligam subscrição → API"))
    print(c(C.Gr, "  " + "─" * 86))
    for grupo, repo, stars, desc in FONTES:
        print(f"  {c(C.Y, pad(grupo, 15))} {c(C.W, pad(repo, 34))} {c(C.G, pad(stars, 8))} {c(C.Gr, desc)}")
    print()


def tela_excluidas():
    print(c(C.P + C.B, "  FORA DO SCRIPT (não cumprem iOS IAP + Windows 100%)"))
    print(c(C.Gr, "  " + "─" * 86))
    for nome, motivo in EXCLUIDAS:
        print(f"  {c(C.Rr, pad(nome, 24))} {c(C.Gr, motivo)}")
    print()


def render_duracao():
    rows = ranking()
    W = WIDTH
    print(c(C.P, "┌" + "─" * W + "┐"))
    t = "DURAÇÃO · 6 workers × 2 tarefas · 1 exec = 2M in + 0,4M out · job 4h"
    print(c(C.P, "│ ") + c(C.W + C.B, pad(t, W - 2)) + c(C.P, " │"))
    print(c(C.P, "╞" + "═" * W + "╡"))
    for i, e in enumerate(rows, 1):
        head = f"{i:02d} ▸ {e['app']}"
        print(c(C.P, "│ ") + c(C.P + C.B, pad(cut(head, 30), 30)) +
              c(C.G, pad(f"conc {e['conc']} · {e['modelos'][0]['modelo']}", W - 32)) + c(C.P, " │"))
        for p in planos_visiveis(e):
            h = p["horas"]
            est = " (est.)" if p["est"] else ""
            linha = ("     " + pad(p["nome"], 10) + " " +
                     red(pad(preco_txt(p["preco"]) + "/mês", 11)) + " " +
                     pad(cut(p["quota"], 22), 22) + " " +
                     pad(f"{h:.0f}h/mês{est}", 14) + " " +
                     pad(f"{h / p['preco']:.2f} h/$", 9))
            print(c(C.P, "│ ") + pad(linha, W - 2) + c(C.P, " │"))
        if i < len(rows):
            print(c(C.P, "├" + "─" * W + "┤"))
    print(c(C.P, "└" + "─" * W + "┘"))
    print(c(C.Gr, "  (est.) = quota não publicada; os demais vêm de credits/quota publicados."))
    print(c(C.Gr, "  'h/mês' = quantas horas de processamento o plano cobre neste cenário."))
    print()


def main():
    ap = argparse.ArgumentParser(description="PANDA GÓTICO — apps iOS IAP + Windows para o ARTEX")
    ap.add_argument("--list", action="store_true", help="ranking")
    ap.add_argument("--print", action="store_true", help="sem cores")
    ap.add_argument("--provider", help="detalhe de um app (id)")
    ap.add_argument("--env", help="mostrar .env de um app (id)")
    ap.add_argument("--model", help="modelo para --env/--auto")
    ap.add_argument("--auto", help="grava .env + sobe PoC + valida modelo (id)")
    ap.add_argument("--env-path", help="caminho do .env (default: pasta do hub)")
    ap.add_argument("--poc-host", default="auto",
                    help="auto (default) | 127.0.0.1 | 0.0.0.0 (Docker)")
    ap.add_argument("--stop", action="store_true",
                    help="para a PoC lançada pelo hub (poc.pid) e liberta a 4141")
    ap.add_argument("--yes", action="store_true", help="não perguntar no --auto")
    ap.add_argument("--faq", help="FAQ de um app (id)")
    ap.add_argument("--duracao", action="store_true", help="horas por plano")
    ap.add_argument("--ios", action="store_true", help="custos IAP iOS")
    ap.add_argument("--fontes", action="store_true", help="projetos de pesquisa")
    ap.add_argument("--excluidas", action="store_true", help="fora do script")
    ap.add_argument("--ids", action="store_true", help="listar ids")
    ap.add_argument("--workload", choices=list(WORKLOADS), default="medio")
    args = ap.parse_args()

    global _COLOR, POC_HOST
    if args.print:
        _COLOR = False
    POC_HOST = resolver_poc_host(args.poc_host)

    if args.ids:
        for e in ranking():
            print(f'{e["id"]:<14} {e["app"]:<26} {e["certeza"]}%')
        return 0
    if args.fontes:
        tela_fontes(); return 0
    if args.excluidas:
        tela_excluidas(); return 0
    if args.ios:
        tela_ios(); return 0
    if args.duracao:
        banner(); render_duracao(); return 0
    if args.provider:
        e = find_ent(args.provider)
        if not e:
            print("id desconhecido. usa --ids"); return 1
        banner(); detalhe(e); return 0
    if args.auto:
        e = find_ent(args.auto)
        if not e:
            print("id desconhecido. usa --ids"); return 1
        o = find_model(e, args.model) if args.model else e["modelos"][0]
        if not o:
            print("modelo desconhecido."); return 1
        banner()
        ok = auto_configurar(e, o, args.env_path, args.yes, interactive=False)
        return 0 if ok else 1
    if args.env:
        e = find_ent(args.env)
        if not e:
            print("id desconhecido. usa --ids"); return 1
        o = find_model(e, args.model) if args.model else e["modelos"][0]
        if not o:
            print("modelo desconhecido."); return 1
        print(env_block(e, o)); return 0
    if args.faq:
        e = find_ent(args.faq)
        if not e:
            print("id desconhecido. usa --ids"); return 1
        mostrar_faq(e); return 0
    if args.stop:
        return parar_poc()

    if args.list:
        banner(); render(args.workload); return 0

    # ---------------- interactivo ----------------
    banner()
    render(args.workload)
    rows = ranking()
    while True:
        print(c(C.P, "  MENU"))
        for i, e in enumerate(rows, 1):
            ps = planos_visiveis(e)
            faixa = (preco_txt(ps[0]["preco"]) if len(ps) == 1
                     else f"{preco_txt(ps[0]['preco'])}–{preco_txt(ps[-1]['preco'])}")
            print(f"   {i}. " + c(C.W, pad(cut(e["app"], 24), 24)) +
                  c(C.Rr, pad(faixa + "/mês", 18)) +
                  c(C.Gr, f"iOS IAP + Windows · {len(ps)} plano{'s' if len(ps) > 1 else ''} · {e['modelos'][0]['modelo']}"))
        print("   " + c(C.W, "[D]") + " duração   " + c(C.W, "[A]") + " ajuda iOS   " +
              c(C.W, "[P]") + " pesquisa   " + c(C.W, "[X]") + " fora do script   " +
              c(C.W, "[S]") + " parar PoC   " + c(C.W, "[Q]") + " sair")
        try:
            op = input(c(C.Cy, "  escolha> ")).strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            print(c(C.Gr, "  ✦ até à próxima, panda. ✦"))
            return 0
        if op in ("q", "sair", "exit"):
            print(c(C.Gr, "  ✦ até à próxima, panda. ✦"))
            return 0
        if op == "d":
            render_duracao()
        elif op == "a":
            tela_ios()
        elif op == "p":
            tela_fontes()
        elif op == "x":
            tela_excluidas()
        elif op == "s":
            parar_poc()
        elif op.isdigit():
            i = int(op)
            if 1 <= i <= len(rows):
                try:
                    menu_ent(rows[i - 1])
                except KeyboardInterrupt:
                    print(c(C.Y, "\n  ⚠ interrompido."))
            else:
                print(c(C.Gr, "  opção inválida."))
        else:
            print(c(C.Gr, "  opção inválida."))


if __name__ == "__main__":
    raise SystemExit(main())
