#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
poc.py — GitHub Copilot -> endpoint OpenAI-compatible (/v1)  [PoC educacional]

O que faz
---------
1. Login via OAuth Device Flow com o client_id público da extensão
   "GitHub Copilot Chat" (o mesmo que o VS Code usa). Nada é roubado:
   tu autorizas a tua própria conta no browser.
2. Troca o token GitHub (gho_...) por um token Copilot de curta duração
   (~30 min) no endpoint /copilot_internal/v2/token.
3. Sobe um servidor HTTP local que imita a API OpenAI:
       GET  /v1/models
       POST /v1/chat/completions   (incl. stream SSE)
   e faz passthrough para https://api.githubcopilot.com.

Uso
---
    python3 poc.py login                 # autoriza + guarda token (modo 600)
    python3 poc.py whoami                # plano + quota (premium_interactions etc.)
    python3 poc.py models                # lista modelos disponíveis na conta
    python3 poc.py ask "olá" -m gpt-4o   # teste one-shot (stream por omissão)
    python3 poc.py serve --port 4141     # sobe o /v1 falso

Depois, em qualquer cliente OpenAI:
    OPENAI_BASE_URL=http://127.0.0.1:4141/v1 OPENAI_API_KEY=dummy ...
ou
    from openai import OpenAI
    c = OpenAI(base_url="http://127.0.0.1:4141/v1", api_key="dummy")
    print(c.chat.completions.create(model="gpt-4o",
          messages=[{"role":"user","content":"olá"}]).choices[0].message.content)

Sem dependências externas (só biblioteca padrão).
ATENÇÃO: usa apenas com a TUA conta. Partilhar/revender a subscrição viola
os ToS da GitHub e pode dar ban. Isto é reuse da tua própria sessão, não um bug.
"""

import argparse
import json
import os
import re
import secrets
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

# --------------------------------------------------------------------------- #
# Config
# --------------------------------------------------------------------------- #
# OAuth App público da extensão Copilot Chat (device flow habilitado).
CLIENT_ID = os.environ.get("COPILOT_CLIENT_ID", "Iv1.b507a08c87ecfe98")

DEVICE_CODE_URL = "https://github.com/login/device/code"
ACCESS_TOKEN_URL = "https://github.com/login/oauth/access_token"
COPILOT_TOKEN_URL = "https://api.github.com/copilot_internal/v2/token"
COPILOT_USER_URL = "https://api.github.com/copilot_internal/user"
DEFAULT_API = "https://api.githubcopilot.com"

# Headers que a API do Copilot valida (sem eles -> 401/403).
EDITOR_HEADERS = {
    "Editor-Version": "vscode/1.95.0",
    "Editor-Plugin-Version": "copilot-chat/0.22.0",
    "Copilot-Integration-Id": "vscode-chat",
    "User-Agent": "GitHubCopilotChat/0.22.0",
}

FALLBACK_MODELS = [
    "gpt-4o", "gpt-4o-mini", "o1", "o1-mini", "o3-mini",
    "claude-3.5-sonnet", "claude-3.7-sonnet", "gemini-2.0-flash-001",
]

TOKEN_FILE = Path(
    os.environ.get("COPILOT_POC_TOKEN", str(Path.home() / ".config" / "copilot-poc" / "token.json"))
)

# Uma chave local por modelo. O ARTEX recusa perfis com a mesma API Key,
# por isso cada modelo precisa de uma chave própria (aleatória mas estável).
KEYS_FILE = TOKEN_FILE.parent / "keys.json"

# Estado partilhado (processo do servidor)
GH_TOKEN = None
LOCAL_API_KEY = None          # string (compat) ou None
LOCAL_API_KEYS = set()        # conjunto de chaves aceites
KEY_TO_MODEL = {}             # chave -> modelo (só informativo)
_initiator_default = "user"


def _slug_modelo(modelo):
    return re.sub(r"[^a-z0-9]+", "-", (modelo or "").lower()).strip("-")[:24]


def load_keys():
    """{modelo: chave} persistido em ~/.config/copilot-poc/keys.json"""
    try:
        d = json.loads(KEYS_FILE.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except Exception:  # noqa: BLE001
        return {}


def save_keys(d):
    try:
        KEYS_FILE.parent.mkdir(parents=True, exist_ok=True)
        KEYS_FILE.write_text(json.dumps(d, indent=2, ensure_ascii=False),
                             encoding="utf-8")
        os.chmod(KEYS_FILE, 0o600)
    except Exception:  # noqa: BLE001
        pass


def chave_do_modelo(modelo):
    """Chave estável por modelo; gera e guarda na primeira vez."""
    d = load_keys()
    k = d.get(modelo)
    if not k:
        k = "sk-poc-" + (_slug_modelo(modelo) or "model") + "-" + secrets.token_hex(8)
        d[modelo] = k
        save_keys(d)
    return k


def registar_chaves(espec):
    """Aceita --api-key a,b,c e/ou todas as chaves de keys.json.

    Com chaves por modelo em keys.json, o ARTEX pode ter um perfil por modelo
    (o UI recusa repetir a mesma key).
    """
    if espec:
        for k in str(espec).split(","):
            k = k.strip()
            if k:
                LOCAL_API_KEYS.add(k)
        return                      # --api-key explícito = modo estrito
    for m, k in load_keys().items():
        if k:
            LOCAL_API_KEYS.add(k)
            KEY_TO_MODEL[k] = m
    if LOCAL_API_KEYS:
        LOCAL_API_KEYS.add("dummy")  # compat: perfis antigos criados com dummy


_keys_mtime = [0.0]


def _reload_keys():
    """Recarrega keys.json se mudou (permite gerar chaves com a PoC no ar)."""
    try:
        m = KEYS_FILE.stat().st_mtime
    except OSError:
        return
    if m <= _keys_mtime[0]:
        return
    _keys_mtime[0] = m
    novo = load_keys()
    if not novo:
        return
    for modelo, k in novo.items():
        if k:
            LOCAL_API_KEYS.add(k)
            KEY_TO_MODEL.setdefault(k, modelo)
    LOCAL_API_KEYS.add("dummy")

# Modo genérico (sem GitHub): aponta o /v1 para qualquer provider OpenAI-compatible.
UPSTREAM = {"base": None, "key": None, "model": None}

# Alguns modelos do Copilot só aceitam /responses (não /chat/completions).
# Guardamos a rota por modelo: "chat" (default) ou "responses".
# É aprendida automaticamente no primeiro erro unsupported_api_for_model.
MODEL_ROUTE = {}

_cop_lock = threading.Lock()
_cop = {"token": None, "exp": 0.0, "api": DEFAULT_API}


# --------------------------------------------------------------------------- #
# HTTP helpers (stdlib)
# --------------------------------------------------------------------------- #
def _decode_body(body, content_type=""):
    """JSON se possível; senão form-urlencoded (endpoints OAuth do GitHub); senão raw."""
    if not body:
        return {}
    try:
        return json.loads(body)
    except ValueError:
        pass
    text = body.decode("utf-8", "replace")
    if "x-www-form-urlencoded" in content_type or "=" in text:
        try:
            return {k: v[0] for k, v in urllib.parse.parse_qs(text).items()}
        except Exception:  # noqa: BLE001
            pass
    return {"raw": text}


def http_json(url, payload=None, headers=None, method=None, timeout=60):
    """Faz um request e devolve (status, dict). Não levanta em 4xx/5xx."""
    hdrs = dict(headers or {})
    data = None
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        hdrs.setdefault("Content-Type", "application/json")
    req = urllib.request.Request(
        url, data=data, headers=hdrs, method=method or ("POST" if data is not None else "GET")
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, _decode_body(r.read(), r.headers.get("Content-Type", ""))
    except urllib.error.HTTPError as e:
        return e.code, _decode_body(e.read(), e.headers.get("Content-Type", "") if e.headers else "")


# --------------------------------------------------------------------------- #
# 1) Device flow
# --------------------------------------------------------------------------- #
def device_login(client_id=CLIENT_ID, scope="read:user"):
    st, j = http_json(
        DEVICE_CODE_URL,
        {"client_id": client_id, "scope": scope},
        headers={"Accept": "application/json"},
    )
    if st != 200 or "device_code" not in j:
        raise SystemExit(f"[!] device/code falhou ({st}): {j}")

    print("[*] Abre no browser:  " + j["verification_uri"])
    print("[*] Introduz o código: " + j["user_code"])
    print("[*] À espera de autorização...")

    interval = int(j.get("interval", 5))
    deadline = time.time() + int(j.get("expires_in", 900))
    while time.time() < deadline:
        time.sleep(interval)
        st, t = http_json(
            ACCESS_TOKEN_URL,
            {
                "client_id": client_id,
                "device_code": j["device_code"],
                "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
            },
            headers={"Accept": "application/json"},
        )
        err = t.get("error")
        if not err and t.get("access_token"):
            return t["access_token"]
        if err == "authorization_pending":
            continue
        if err == "slow_down":
            interval += 5
            continue
        raise SystemExit(f"[!] login falhou: {t}")
    raise SystemExit("[!] device code expirou; corre outra vez.")


def load_gh_token():
    if TOKEN_FILE.exists():
        try:
            return json.loads(TOKEN_FILE.read_text())["github_token"]
        except Exception:
            return None
    return None


def save_gh_token(token):
    TOKEN_FILE.parent.mkdir(parents=True, exist_ok=True)
    TOKEN_FILE.write_text(json.dumps({"github_token": token}))
    try:
        os.chmod(TOKEN_FILE, 0o600)
    except OSError:
        pass
    return token


def ensure_gh_token(interactive=True):
    tok = load_gh_token()
    if tok:
        return tok
    if not interactive:
        raise SystemExit("[!] Sem token guardado. Corre: python3 poc.py login")
    print("[*] Sem token guardado -> device flow.")
    tok = device_login()
    save_gh_token(tok)
    print(f"[+] Token guardado em {TOKEN_FILE} (chmod 600)")
    return tok


# --------------------------------------------------------------------------- #
# 2) Troca GitHub token -> Copilot token (com refresh automático)
# --------------------------------------------------------------------------- #
def copilot_token(gh_token, force=False):
    """Devolve (token_copilot, base_api). Renova ~5 min antes de expirar."""
    with _cop_lock:
        if not force and _cop["token"] and time.time() < _cop["exp"] - 300:
            return _cop["token"], _cop["api"]

        st, j = http_json(
            COPILOT_TOKEN_URL,
            headers={"Authorization": f"token {gh_token}", "Accept": "application/json", **EDITOR_HEADERS},
        )
        if st != 200 or "token" not in j:
            raise RuntimeError(f"troca de token falhou ({st}): {j}")

        _cop["token"] = j["token"]
        _cop["exp"] = float(j.get("expires_at") or (time.time() + 1500))
        _cop["api"] = (j.get("endpoints") or {}).get("api") or DEFAULT_API
        return _cop["token"], _cop["api"]


def copilot_headers(cop_token, initiator=None):
    return {
        "Authorization": f"Bearer {cop_token}",
        "Content-Type": "application/json",
        "X-Initiator": initiator or _initiator_default,
        **EDITOR_HEADERS,
    }


# --------------------------------------------------------------------------- #
# 3) Comandos utilitários
# --------------------------------------------------------------------------- #
def cmd_whoami():
    gh = ensure_gh_token()
    st, j = http_json(COPILOT_USER_URL, headers={"Authorization": f"token {gh}", **EDITOR_HEADERS})
    print(f"[*] GET copilot_internal/user -> {st}")
    print(json.dumps(j, indent=2, ensure_ascii=False))


def list_models(gh):
    if UPSTREAM["base"]:
        try:
            st, j = http_json(
                f"{UPSTREAM['base']}/models",
                headers={"Authorization": f"Bearer {UPSTREAM['key']}"},
                timeout=30,
            )
            if st == 200 and isinstance(j.get("data"), list):
                ids = [m.get("id") for m in j["data"] if m.get("id")]
                if ids:
                    return ids
        except Exception as e:  # noqa: BLE001
            print(f"[~] /models upstream falhou ({e}); uso lista estática.", file=sys.stderr)
        base = [UPSTREAM["model"]] if UPSTREAM["model"] else FALLBACK_MODELS
        return _com_chaves(base)
    try:
        tok, api = copilot_token(gh)
        st, j = http_json(f"{api}/models", headers=copilot_headers(tok), timeout=30)
        if st == 200 and isinstance(j.get("data"), list):
            ids = [m.get("id") for m in j["data"] if m.get("id")]
            if ids:
                return _com_chaves(ids)
        else:
            print(f"[~] /models upstream devolveu {st}; uso lista estática.", file=sys.stderr)
    except Exception as e:  # noqa: BLE001
        print(f"[~] /models falhou ({e}); uso lista estática.", file=sys.stderr)
    return _com_chaves(FALLBACK_MODELS)


def _com_chaves(ids):
    """Junta ao catálogo os modelos que já têm chave local (keys.json).

    Sem isto, quando o upstream falha o /v1/models cai na lista estática
    e o hub diria que o modelo escolhido "não está no catálogo".
    """
    extra = [m for m in load_keys() if m]
    return list(dict.fromkeys(list(ids) + extra))


def cmd_models():
    gh = ensure_gh_token()
    for m in list_models(gh):
        print(m)


def cmd_keys(extra=None):
    """Mostra (e gera) uma chave local por modelo.

    O ARTEX não aceita dois perfis com a mesma API Key — daí uma chave por
    modelo. As chaves ficam em ~/.config/copilot-poc/keys.json.
    """
    modelos = []
    try:
        gh = ensure_gh_token(interactive=False)
        modelos = list_models(gh)
    except SystemExit:
        modelos = list(FALLBACK_MODELS)
    except Exception:  # noqa: BLE001
        modelos = list(FALLBACK_MODELS)
    for m in (extra or []):
        if m and m not in modelos:
            modelos.append(m)

    d = load_keys()
    novos = 0
    for m in modelos:
        if m not in d:
            d[m] = chave_do_modelo(m)
            novos += 1
    if modelos:
        save_keys(d)

    larg = max([len(k) for k in d] + [10])
    print(f"# {KEYS_FILE}  (chmod 600)")
    print(f"{'MODELO'.ljust(larg)}  CHAVE")
    for m in sorted(d):
        print(f"{m.ljust(larg)}  {d[m]}")
    if novos:
        print(f"\n[+] {novos} chave(s) nova(s) gerada(s).")
    print("\nNo perfil do ARTEX: um perfil por modelo, cada um com a SUA chave.")
    print("Na PoC: python poc.py serve --api-key " + ",".join(
        sorted({d[m] for m in d})[:2]) + ",...")


def cmd_ask(args):
    gh = ensure_gh_token()
    tok, api = copilot_token(gh)
    body = {
        "model": args.model,
        "messages": [{"role": "user", "content": args.prompt}],
        "stream": not args.no_stream,
    }
    req = urllib.request.Request(
        f"{api}/chat/completions",
        data=json.dumps(body).encode("utf-8"),
        headers=copilot_headers(tok),
        method="POST",
    )
    try:
        resp = urllib.request.urlopen(req, timeout=300)
    except urllib.error.HTTPError as e:
        raise SystemExit(f"[!] upstream {e.code}: {e.read().decode('utf-8', 'replace')}")

    with resp:
        if args.no_stream:
            j = json.loads(resp.read())
            print(j["choices"][0]["message"]["content"])
            return
        for raw in resp:
            line = raw.decode("utf-8", "replace").strip()
            if not line.startswith("data:"):
                continue
            data = line[5:].strip()
            if data == "[DONE]":
                break
            try:
                j = json.loads(data)
            except ValueError:
                continue
            delta = (j.get("choices") or [{}])[0].get("delta") or {}
            chunk = delta.get("content")
            if chunk:
                sys.stdout.write(chunk)
                sys.stdout.flush()
        print()


# --------------------------------------------------------------------------- #
# 4) Compatibilidade: /v1/responses (OpenAI Responses API) -> chat/completions
# --------------------------------------------------------------------------- #
# O ARTEX tem três "format" no perfil LLM:
#   anthropic | openai (Chat Completions) | openai-responses (Responses API)
# Se escolheres "OpenAI (Responses API)", ele chama /v1/responses.
# Aqui traduzimos para /v1/chat/completions (que é o que o Copilot fala)
# e devolvemos a resposta no formato Responses.


def _resp_text_parts(content):
    """Converte content do Responses API para content do Chat Completions."""
    if isinstance(content, str):
        return content, []
    if not isinstance(content, list):
        return "", []
    textos, imagens = [], []
    for p in content:
        if not isinstance(p, dict):
            continue
        t = p.get("type") or ""
        if t in ("input_text", "output_text", "text", "summary_text"):
            textos.append(p.get("text") or "")
        elif t in ("input_image", "image_url"):
            url = p.get("image_url") or p.get("url") or ""
            if isinstance(url, dict):
                url = url.get("url") or ""
            if url:
                imagens.append({"type": "image_url", "image_url": {"url": url}})
    if imagens:
        return None, [{"type": "text", "text": "\n".join(textos)}] + imagens
    return "\n".join(textos), []


def _resp_tools(tools):
    """Tools do Responses API (planas) -> Chat Completions (aninhadas)."""
    out = []
    for t in tools or []:
        if not isinstance(t, dict) or t.get("type") != "function":
            continue
        if "function" in t:                       # já vem no formato chat
            out.append(t)
            continue
        fn = {
            "name": t.get("name") or "",
            "description": t.get("description") or "",
            "parameters": t.get("parameters") or {"type": "object", "properties": {}},
        }
        if "strict" in t:
            fn["strict"] = t["strict"]
        out.append({"type": "function", "function": fn})
    return out


def responses_to_chat(body):
    """Traduz um pedido /v1/responses para /v1/chat/completions."""
    msgs = []
    instr = body.get("instructions")
    if instr:
        msgs.append({"role": "system", "content": instr})

    inp = body.get("input")
    if isinstance(inp, str):
        msgs.append({"role": "user", "content": inp})
    elif isinstance(inp, list):
        for it in inp:
            if not isinstance(it, dict):
                if isinstance(it, str):
                    msgs.append({"role": "user", "content": it})
                continue
            typ = it.get("type") or ("message" if it.get("role") else "")
            if typ in ("message", ""):
                role = it.get("role") or "user"
                role = "system" if role in ("developer", "system") else role
                txt, parts = _resp_text_parts(it.get("content"))
                msgs.append({"role": role, "content": parts if parts else (txt or "")})
            elif typ == "function_call":
                msgs.append({
                    "role": "assistant",
                    "content": None,
                    "tool_calls": [{
                        "id": it.get("call_id") or it.get("id") or "call_0",
                        "type": "function",
                        "function": {
                            "name": it.get("name") or "",
                            "arguments": it.get("arguments") or "{}",
                        },
                    }],
                })
            elif typ == "function_call_output":
                out = it.get("output")
                if not isinstance(out, str):
                    out = json.dumps(out, ensure_ascii=False)
                msgs.append({
                    "role": "tool",
                    "tool_call_id": it.get("call_id") or "",
                    "content": out,
                })
            elif typ == "reasoning":
                continue
            else:
                txt, _ = _resp_text_parts(it.get("content") or it.get("text"))
                if txt:
                    msgs.append({"role": "user", "content": txt})

    chat = {"model": body.get("model"), "messages": msgs}
    if body.get("max_output_tokens"):
        chat["max_tokens"] = body["max_output_tokens"]
    for k in ("temperature", "top_p"):
        if body.get(k) is not None:
            chat[k] = body[k]
    tools = _resp_tools(body.get("tools"))
    if tools:
        chat["tools"] = tools
        if body.get("tool_choice") is not None:
            tc = body["tool_choice"]
            if isinstance(tc, dict) and tc.get("type") == "function" and "function" not in tc:
                tc = {"type": "function", "function": {"name": tc.get("name") or ""}}
            chat["tool_choice"] = tc
    fmt = ((body.get("text") or {}).get("format") or {})
    if fmt.get("type") == "json_schema":
        spec = {"name": fmt.get("name") or "out", "schema": fmt.get("schema") or {}}
        if "strict" in fmt:
            spec["strict"] = fmt["strict"]
        chat["response_format"] = {"type": "json_schema", "json_schema": spec}
    elif fmt.get("type") == "json_object":
        chat["response_format"] = {"type": "json_object"}
    return chat


def _rid(prefix):
    return prefix + uuid.uuid4().hex[:24]


def _usage_resp(u):
    u = u or {}
    it = u.get("prompt_tokens") or u.get("input_tokens") or 0
    ot = u.get("completion_tokens") or u.get("output_tokens") or 0
    return {
        "input_tokens": it,
        "input_tokens_details": {"cached_tokens": 0},
        "output_tokens": ot,
        "output_tokens_details": {"reasoning_tokens": 0},
        "total_tokens": u.get("total_tokens") or (it + ot),
    }


def chat_to_responses(chat, model, rid=None):
    """Traduz a resposta do chat/completions para o objeto Responses."""
    rid = rid or _rid("resp_")
    ch = (chat.get("choices") or [{}])[0]
    msg = ch.get("message") or {}
    out = []
    texto = msg.get("content")
    if isinstance(texto, list):
        texto = "".join(p.get("text", "") for p in texto if isinstance(p, dict))
    if texto:
        out.append({
            "id": _rid("msg_"),
            "type": "message",
            "status": "completed",
            "role": "assistant",
            "content": [{"type": "output_text", "text": texto, "annotations": []}],
        })
    for tc in msg.get("tool_calls") or []:
        fn = tc.get("function") or {}
        out.append({
            "id": _rid("fc_"),
            "type": "function_call",
            "status": "completed",
            "call_id": tc.get("id") or _rid("call_"),
            "name": fn.get("name") or "",
            "arguments": fn.get("arguments") or "{}",
        })
    return {
        "id": rid,
        "object": "response",
        "created_at": int(time.time()),
        "status": "completed",
        "error": None,
        "incomplete_details": None,
        "instructions": None,
        "model": model or chat.get("model") or "",
        "output": out,
        "parallel_tool_calls": True,
        "temperature": None,
        "tool_choice": "auto",
        "tools": [],
        "top_p": None,
        "max_output_tokens": None,
        "previous_response_id": None,
        "reasoning": None,
        "store": False,
        "truncation": "disabled",
        "usage": _usage_resp(chat.get("usage")),
        "metadata": {},
    }


# --------------------------------------------------------------------------- #
# 4b) Inverso: chat/completions -> responses (para modelos que só falam Responses)
# --------------------------------------------------------------------------- #
def _flat_tools(tools):
    """Tools aninhadas (chat) -> planas (Responses)."""
    out = []
    for t in tools or []:
        if not isinstance(t, dict):
            continue
        if t.get("type") == "function" and "function" in t:
            fn = t.get("function") or {}
            item = {
                "type": "function",
                "name": fn.get("name") or "",
                "description": fn.get("description") or "",
                "parameters": fn.get("parameters") or {"type": "object", "properties": {}},
            }
            if "strict" in fn:
                item["strict"] = fn["strict"]
            out.append(item)
        else:
            out.append(t)
    return out


def chat_to_responses_req(chat):
    """Traduz um pedido /v1/chat/completions para /v1/responses."""
    instr, items = [], []
    for m in chat.get("messages") or []:
        if not isinstance(m, dict):
            continue
        role = m.get("role") or "user"
        content = m.get("content")

        if role in ("system", "developer"):
            if isinstance(content, list):
                content = "\n".join(p.get("text", "") for p in content
                                    if isinstance(p, dict))
            instr.append(content or "")
            continue

        if role == "tool":
            out = content
            if not isinstance(out, str):
                out = json.dumps(out, ensure_ascii=False)
            items.append({"type": "function_call_output",
                          "call_id": m.get("tool_call_id") or "",
                          "output": out})
            continue

        if role == "assistant":
            txt = content
            if isinstance(txt, list):
                txt = "".join(p.get("text", "") for p in txt if isinstance(p, dict))
            if txt:
                items.append({"type": "message", "role": "assistant",
                              "content": [{"type": "output_text", "text": txt}]})
            for tc in m.get("tool_calls") or []:
                fn = tc.get("function") or {}
                items.append({"type": "function_call",
                              "call_id": tc.get("id") or "",
                              "name": fn.get("name") or "",
                              "arguments": fn.get("arguments") or "{}"})
            continue

        if isinstance(content, list):
            parts = []
            for p in content:
                if not isinstance(p, dict):
                    continue
                if p.get("type") == "text":
                    parts.append({"type": "input_text", "text": p.get("text") or ""})
                elif p.get("type") == "image_url":
                    u = p.get("image_url")
                    if isinstance(u, dict):
                        u = u.get("url")
                    if u:
                        parts.append({"type": "input_image", "image_url": u})
            items.append({"type": "message", "role": "user", "content": parts})
        else:
            items.append({"type": "message", "role": "user",
                          "content": [{"type": "input_text", "text": content or ""}]})

    out = {"model": chat.get("model"), "input": items, "store": False}
    if instr:
        out["instructions"] = "\n\n".join(i for i in instr if i)
    if chat.get("max_tokens") is not None:
        out["max_output_tokens"] = chat["max_tokens"]
    elif chat.get("max_completion_tokens") is not None:
        out["max_output_tokens"] = chat["max_completion_tokens"]
    for k in ("temperature", "top_p"):
        if chat.get(k) is not None:
            out[k] = chat[k]

    tools = _flat_tools(chat.get("tools"))
    if tools:
        out["tools"] = tools
        tc = chat.get("tool_choice")
        if tc is not None:
            if isinstance(tc, dict) and "function" in tc:
                tc = {"type": "function",
                      "name": (tc.get("function") or {}).get("name") or ""}
            out["tool_choice"] = tc

    rf = chat.get("response_format") or {}
    if rf.get("type") == "json_schema":
        spec = rf.get("json_schema") or {}
        out["text"] = {"format": {
            "type": "json_schema",
            "name": spec.get("name") or "out",
            "schema": spec.get("schema") or {},
            "strict": spec.get("strict", True),
        }}
    elif rf.get("type") == "json_object":
        out["text"] = {"format": {"type": "json_object"}}

    if chat.get("stream"):
        out["stream"] = True
    return out


def responses_to_chat_completion(obj, model=None):
    """Objeto Responses -> objeto chat.completion."""
    texto, tcs = [], []
    for it in obj.get("output") or []:
        if not isinstance(it, dict):
            continue
        t = it.get("type")
        if t == "message":
            for c in it.get("content") or []:
                if isinstance(c, dict) and c.get("type") in ("output_text", "text"):
                    texto.append(c.get("text") or "")
        elif t == "function_call":
            tcs.append({
                "id": it.get("call_id") or it.get("id") or _rid("call_"),
                "type": "function",
                "function": {
                    "name": it.get("name") or "",
                    "arguments": it.get("arguments") or "{}",
                },
            })
    msg = {"role": "assistant", "content": "".join(texto) if texto else None}
    if tcs:
        msg["tool_calls"] = tcs
    u = obj.get("usage") or {}
    pit = u.get("input_tokens") or 0
    pot = u.get("output_tokens") or 0
    return {
        "id": "chatcmpl-" + uuid.uuid4().hex[:24],
        "object": "chat.completion",
        "created": int(time.time()),
        "model": model or obj.get("model") or "",
        "choices": [{
            "index": 0,
            "message": msg,
            "finish_reason": "tool_calls" if tcs else "stop",
        }],
        "usage": {
            "prompt_tokens": pit,
            "completion_tokens": pot,
            "total_tokens": u.get("total_tokens") or (pit + pot),
        },
    }


def _needs_responses(obj):
    """True se o upstream recusou o modelo por ser só de /responses."""
    if not isinstance(obj, dict):
        return False
    err = obj.get("error")
    if isinstance(err, dict):
        blob = json.dumps(err, ensure_ascii=False).lower()
    else:
        blob = json.dumps(obj, ensure_ascii=False).lower()
    return ("unsupported_api_for_model" in blob
            or ("not accessible via the /chat/completions" in blob))


# --------------------------------------------------------------------------- #
# 5) Servidor /v1 falso
# --------------------------------------------------------------------------- #
class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "copilot-poc/0.1"

    def log_message(self, fmt, *a):
        sys.stderr.write(f"[srv] {self.address_string()} {fmt % a}\n")

    # --- helpers ---
    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")

    def _json(self, code, obj):
        data = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self._cors()
        self.end_headers()
        self.wfile.write(data)

    def _html(self, code, html):
        data = html.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self._cors()
        self.end_headers()
        self.wfile.write(data)

    def _auth_ok(self):
        _reload_keys()
        if not LOCAL_API_KEYS:
            return True
        h = (self.headers.get("Authorization", "") or "").strip()
        if h.lower().startswith("bearer "):
            h = h[7:].strip()
        if not h:
            h = (self.headers.get("x-api-key", "") or "").strip()
        if h and h in LOCAL_API_KEYS:
            return True
        # consome o body para não desalinhar a ligação keep-alive
        try:
            n = int(self.headers.get("Content-Length") or 0)
            if n:
                self.rfile.read(n)
        except Exception:  # noqa: BLE001
            pass
        self._json(401, {"error": {
            "message": "invalid api key",
            "hint": "usa a chave gerada para este modelo (python poc.py keys)",
        }})
        return False

    # --- rotas ---
    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Content-Length", "0")
        self._cors()
        self.end_headers()

    def do_GET(self):
        path = self.path.split("?", 1)[0].rstrip("/")
        if path in ("/health", "/v1/health"):
            return self._json(200, {"ok": True})
        if path == "":
            port = self.server.server_address[1]
            return self._html(200, LANDING.replace("{{PORT}}", str(port)))
        if path == "/v1":
            # alguns clientes (ex.: o "Test" do ARTEX) fazem GET na base do /v1
            return self._json(200, {
                "ok": True,
                "service": "copilot-poc",
                "endpoints": ["/v1/models", "/v1/chat/completions", "/v1/responses"],
            })
        if path in ("/models", "/v1/models"):
            # catálogo: não exige chave (o "Test" de alguns clientes só faz
            # GET /models e falharia com 401). As chaves só travam o chat.
            try:
                ids = list_models(GH_TOKEN)
            except Exception:  # noqa: BLE001
                ids = FALLBACK_MODELS
            owner = "upstream" if UPSTREAM["base"] else "github-copilot"
            return self._json(
                200,
                {"object": "list", "data": [{"id": m, "object": "model", "owned_by": owner} for m in ids]},
            )
        self._json(404, {"error": {"message": f"rota desconhecida: {self.path}"}})

    def _upstream_target(self):
        """(base_api, headers). Em erro já respondeu e devolve (None, None)."""
        if UPSTREAM["base"]:
            return UPSTREAM["base"], {
                "Authorization": f"Bearer {UPSTREAM['key']}",
                "Content-Type": "application/json",
            }
        try:
            tok, api = copilot_token(GH_TOKEN)
        except Exception as e:  # noqa: BLE001
            self._json(502, {"error": {"message": f"token: {e}"}})
            return None, None
        initiator = self.headers.get("X-Initiator") or _initiator_default
        return api, copilot_headers(tok, initiator)

    def _handle_responses(self):
        """POST /v1/responses -> /v1/chat/completions -> objeto/SSE Responses."""
        if not self._auth_ok():
            return
        n = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(n) if n else b"{}"
        try:
            body = json.loads(raw or b"{}")
        except ValueError:
            return self._json(400, {"error": {"message": "JSON inválido"}})

        chat = responses_to_chat(body)
        if UPSTREAM["model"]:
            chat["model"] = UPSTREAM["model"]
        model = chat.get("model") or ""
        stream = bool(body.get("stream"))

        api, hdrs = self._upstream_target()
        if api is None:
            return
        outp = dict(body)
        outp["model"] = model
        if MODEL_ROUTE.get(model) == "responses":
            return self._native_responses(outp, api, hdrs)
        chat["stream"] = stream
        req = urllib.request.Request(
            f"{api}/chat/completions",
            data=json.dumps(chat).encode("utf-8"),
            headers=hdrs,
            method="POST",
        )
        try:
            resp = urllib.request.urlopen(req, timeout=300)
        except urllib.error.HTTPError as e:
            payload = e.read()
            try:
                ej = json.loads(payload)
            except ValueError:
                ej = None
            if ej is not None and _needs_responses(ej):
                MODEL_ROUTE[model] = "responses"
                sys.stderr.write(
                    f"[srv] '{model}' so aceita /responses no upstream; "
                    "a reencaminhar (fica memorizado)\n")
                return self._native_responses(outp, api, hdrs)
            if ej is not None:
                return self._json(e.code, ej)
            return self._json(e.code, {
                "error": {"message": payload.decode("utf-8", "replace")}
            })

        with resp:
            if not stream:
                data = resp.read()
                try:
                    cj = json.loads(data)
                except ValueError:
                    return self._json(502, {
                        "error": {"message": "upstream não devolveu JSON"}
                    })
                return self._json(200, chat_to_responses(cj, model))

            ctype = resp.headers.get("Content-Type", "")
            if "text/event-stream" not in ctype:
                # upstream ignorou stream=true: embrulha a resposta inteira
                cj = json.loads(resp.read() or b"{}")
                obj = chat_to_responses(cj, model)
                return self._json(200, obj)

            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "keep-alive")
            self.send_header("Transfer-Encoding", "chunked")
            self._cors()
            self.end_headers()

            rid = _rid("resp_")
            st = {"seq": 0}
            msg_id = _rid("msg_")
            opened = {"msg": False}
            out_idx = {"n": 0}
            tools = {}

            def emit(event, obj):
                obj.setdefault("type", event)
                obj["sequence_number"] = st["seq"]
                st["seq"] += 1
                frame = (f"event: {event}\ndata: "
                         + json.dumps(obj, ensure_ascii=False) + "\n\n").encode("utf-8")
                self.wfile.write(b"%x\r\n" % len(frame) + frame + b"\r\n")
                self.wfile.flush()

            base = {
                "id": rid, "object": "response", "created_at": int(time.time()),
                "status": "in_progress", "model": model, "output": [],
            }
            try:
                emit("response.created", {"response": base})
                emit("response.in_progress", {"response": base})

                def open_msg():
                    if opened["msg"]:
                        return
                    opened["msg"] = True
                    emit("response.output_item.added", {
                        "output_index": out_idx["n"],
                        "item": {"id": msg_id, "type": "message", "status": "in_progress",
                                 "role": "assistant", "content": []},
                    })
                    emit("response.content_part.added", {
                        "item_id": msg_id, "output_index": out_idx["n"],
                        "content_index": 0,
                        "part": {"type": "output_text", "text": "", "annotations": []},
                    })

                buf = b""
                texto = []
                while True:
                    chunk = resp.read1(4096) if hasattr(resp, "read1") else resp.read(4096)
                    if not chunk:
                        break
                    buf += chunk
                    while b"\n" in buf:
                        line, buf = buf.split(b"\n", 1)
                        line = line.strip()
                        if not line.startswith(b"data:"):
                            continue
                        payload = line[5:].strip()
                        if payload == b"[DONE]":
                            continue
                        try:
                            ev = json.loads(payload)
                        except ValueError:
                            continue
                        delta = ((ev.get("choices") or [{}])[0].get("delta") or {})
                        d = delta.get("content")
                        if d:
                            open_msg()
                            texto.append(d)
                            emit("response.output_text.delta", {
                                "item_id": msg_id, "output_index": out_idx["n"],
                                "content_index": 0, "delta": d,
                            })
                        for tc in delta.get("tool_calls") or []:
                            i = tc.get("index", 0)
                            cur = tools.setdefault(i, {"id": None, "name": "", "args": ""})
                            if tc.get("id"):
                                cur["id"] = tc["id"]
                            fn = tc.get("function") or {}
                            if fn.get("name"):
                                cur["name"] += fn["name"]
                            if fn.get("arguments"):
                                cur["args"] += fn["arguments"]

                if opened["msg"]:
                    full = "".join(texto)
                    emit("response.output_text.done", {
                        "item_id": msg_id, "output_index": out_idx["n"],
                        "content_index": 0, "text": full,
                    })
                    emit("response.content_part.done", {
                        "item_id": msg_id, "output_index": out_idx["n"],
                        "content_index": 0,
                        "part": {"type": "output_text", "text": full, "annotations": []},
                    })
                    emit("response.output_item.done", {
                        "output_index": out_idx["n"],
                        "item": {"id": msg_id, "type": "message", "status": "completed",
                                 "role": "assistant",
                                 "content": [{"type": "output_text", "text": full,
                                              "annotations": []}]},
                    })
                    out_idx["n"] += 1

                for i in sorted(tools):
                    t = tools[i]
                    if not t["name"]:
                        continue
                    fc_id = _rid("fc_")
                    call_id = t["id"] or _rid("call_")
                    item = {"id": fc_id, "type": "function_call", "status": "in_progress",
                            "call_id": call_id, "name": t["name"], "arguments": ""}
                    emit("response.output_item.added",
                         {"output_index": out_idx["n"], "item": item})
                    emit("response.function_call_arguments.delta", {
                        "item_id": fc_id, "output_index": out_idx["n"], "delta": t["args"],
                    })
                    emit("response.function_call_arguments.done", {
                        "item_id": fc_id, "output_index": out_idx["n"],
                        "arguments": t["args"],
                    })
                    emit("response.output_item.done", {
                        "output_index": out_idx["n"],
                        "item": {"id": fc_id, "type": "function_call",
                                 "status": "completed", "call_id": call_id,
                                 "name": t["name"], "arguments": t["args"]},
                    })
                    out_idx["n"] += 1

                done = dict(base)
                done["status"] = "completed"
                emit("response.completed", {"response": done})
            except (BrokenPipeError, ConnectionResetError):
                pass
            finally:
                try:
                    self.wfile.write(b"0\r\n\r\n")
                    self.wfile.flush()
                except Exception:  # noqa: BLE001
                    pass

    def _via_responses(self, chat, api, hdrs):
        """Atende um pedido chat/completions usando /responses do upstream."""
        body = chat_to_responses_req(chat)
        model = body.get("model") or ""
        stream = bool(body.get("stream"))
        body["stream"] = stream
        req = urllib.request.Request(
            f"{api}/responses",
            data=json.dumps(body).encode("utf-8"),
            headers=hdrs,
            method="POST",
        )
        try:
            resp = urllib.request.urlopen(req, timeout=300)
        except urllib.error.HTTPError as e:
            payload = e.read()
            try:
                return self._json(e.code, json.loads(payload))
            except ValueError:
                return self._json(e.code, {
                    "error": {"message": payload.decode("utf-8", "replace")}
                })
        except Exception as e:  # noqa: BLE001
            return self._json(502, {"error": {"message": f"upstream: {e}"}})

        with resp:
            ctype = resp.headers.get("Content-Type", "")
            if not stream or "text/event-stream" not in ctype:
                try:
                    obj = json.loads(resp.read() or b"{}")
                except ValueError:
                    return self._json(502, {
                        "error": {"message": "upstream /responses devolveu JSON inválido"}
                    })
                return self._json(200, responses_to_chat_completion(obj, model))

            # streaming: eventos Responses -> chunks chat.completion.chunk
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "keep-alive")
            self.send_header("Transfer-Encoding", "chunked")
            self._cors()
            self.end_headers()

            cid = "chatcmpl-" + uuid.uuid4().hex[:24]
            ts = int(time.time())

            def wr(obj):
                frame = ("data: " + json.dumps(obj, ensure_ascii=False)
                         + "\n\n").encode("utf-8")
                self.wfile.write(b"%x\r\n" % len(frame) + frame + b"\r\n")
                self.wfile.flush()

            def chunk(delta, finish=None):
                wr({"id": cid, "object": "chat.completion.chunk", "created": ts,
                    "model": model,
                    "choices": [{"index": 0, "delta": delta,
                                 "finish_reason": finish}]})

            tcidx = {}
            finished = {"v": False}
            started = {"role": False}
            try:
                chunk({"role": "assistant", "content": ""})
                started["role"] = True
                buf = b""
                while True:
                    part = resp.read1(4096) if hasattr(resp, "read1") else resp.read(4096)
                    if not part:
                        break
                    buf += part
                    while b"\n" in buf:
                        line, buf = buf.split(b"\n", 1)
                        line = line.strip()
                        if not line.startswith(b"data:"):
                            continue
                        payload = line[5:].strip()
                        if not payload or payload == b"[DONE]":
                            continue
                        try:
                            ev = json.loads(payload)
                        except ValueError:
                            continue
                        et = ev.get("type") or ""
                        if et == "response.output_text.delta":
                            d = ev.get("delta")
                            if d:
                                chunk({"content": d})
                        elif et == "response.output_item.added":
                            it = ev.get("item") or {}
                            if it.get("type") == "function_call":
                                i = len(tcidx)
                                tcidx[it.get("id") or it.get("call_id") or str(i)] = i
                                chunk({"tool_calls": [{
                                    "index": i,
                                    "id": it.get("call_id") or it.get("id") or _rid("call_"),
                                    "type": "function",
                                    "function": {"name": it.get("name") or "",
                                                 "arguments": ""},
                                }]})
                        elif et == "response.function_call_arguments.delta":
                            key = ev.get("item_id") or ""
                            i = tcidx.get(key, 0)
                            d = ev.get("delta")
                            if d:
                                chunk({"tool_calls": [{
                                    "index": i,
                                    "function": {"arguments": d},
                                }]})
                        elif et in ("response.completed", "response.done"):
                            chunk({}, "tool_calls" if tcidx else "stop")
                            finished["v"] = True
                if not finished["v"]:
                    chunk({}, "tool_calls" if tcidx else "stop")
                self.wfile.write(b"data: [DONE]\n\n")
                self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError):
                pass
            finally:
                try:
                    self.wfile.write(b"0\r\n\r\n")
                    self.wfile.flush()
                except Exception:  # noqa: BLE001
                    pass

    def _native_responses(self, body, api, hdrs):
        """Passthrough para o /responses do upstream (já é formato Responses)."""
        body.setdefault("store", False)
        stream = bool(body.get("stream"))
        req = urllib.request.Request(
            f"{api}/responses",
            data=json.dumps(body).encode("utf-8"),
            headers=hdrs,
            method="POST",
        )
        try:
            resp = urllib.request.urlopen(req, timeout=300)
        except urllib.error.HTTPError as e:
            payload = e.read()
            try:
                return self._json(e.code, json.loads(payload))
            except ValueError:
                return self._json(e.code, {
                    "error": {"message": payload.decode("utf-8", "replace")}
                })
        except Exception as e:  # noqa: BLE001
            return self._json(502, {"error": {"message": f"upstream: {e}"}})

        with resp:
            ctype = resp.headers.get("Content-Type", "application/json")
            if "text/event-stream" not in ctype:
                data = resp.read()
                self.send_response(resp.status)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(data)))
                self._cors()
                self.end_headers()
                self.wfile.write(data)
                return
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Transfer-Encoding", "chunked")
            self._cors()
            self.end_headers()
            try:
                while True:
                    part = resp.read1(4096) if hasattr(resp, "read1") else resp.read(4096)
                    if not part:
                        break
                    self.wfile.write(b"%x\r\n" % len(part) + part + b"\r\n")
                    self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError):
                pass
            finally:
                try:
                    self.wfile.write(b"0\r\n\r\n")
                    self.wfile.flush()
                except Exception:  # noqa: BLE001
                    pass

    def do_POST(self):
        path = self.path.split("?", 1)[0].rstrip("/")
        if path in ("/v1/responses", "/responses"):
            return self._handle_responses()
        if path not in (
            "/v1/chat/completions", "/chat/completions",
            "/v1/completions", "/completions",
        ):
            return self._json(404, {"error": {"message": f"rota desconhecida: {self.path}"}})
        if not self._auth_ok():
            return

        n = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(n) if n else b"{}"
        try:
            body = json.loads(raw or b"{}")
        except ValueError:
            return self._json(400, {"error": {"message": "JSON inválido"}})

        if UPSTREAM["base"]:
            # Modo genérico: qualquer provider OpenAI-compatible (Z.ai, OpenRouter, ...)
            api = UPSTREAM["base"]
            if UPSTREAM["model"]:
                body["model"] = UPSTREAM["model"]
            # Z.ai: tool calls em streaming só saem completos com tool_stream
            if ("z.ai" in api or "/paas/v4" in api) and body.get("stream") and body.get("tools"):
                body.setdefault("tool_stream", True)
            hdrs = {
                "Authorization": f"Bearer {UPSTREAM['key']}",
                "Content-Type": "application/json",
            }
        else:
            try:
                tok, api = copilot_token(GH_TOKEN)
            except Exception as e:  # noqa: BLE001
                return self._json(502, {"error": {"message": f"token: {e}"}})
            # respeita X-Initiator do cliente; senão usa o default
            initiator = self.headers.get("X-Initiator") or _initiator_default
            hdrs = copilot_headers(tok, initiator)

        upstream = f"{api}/chat/completions"
        model = body.get("model") or ""
        if MODEL_ROUTE.get(model) == "responses":
            return self._via_responses(body, api, hdrs)

        req = urllib.request.Request(
            upstream,
            data=json.dumps(body).encode("utf-8"),
            headers=hdrs,
            method="POST",
        )
        try:
            resp = urllib.request.urlopen(req, timeout=300)
        except urllib.error.HTTPError as e:
            payload = e.read()
            try:
                ej = json.loads(payload)
            except ValueError:
                ej = None
            if ej is not None and _needs_responses(ej):
                MODEL_ROUTE[model] = "responses"
                sys.stderr.write(
                    f"[srv] '{model}' so aceita /responses no upstream; "
                    "a reencaminhar (fica memorizado)\n")
                return self._via_responses(body, api, hdrs)
            if ej is not None:
                return self._json(e.code, ej)
            return self._json(e.code, {"error": {"message": payload.decode("utf-8", "replace")}})

        ctype = resp.headers.get("Content-Type", "application/json")
        with resp:
            if "text/event-stream" not in ctype:
                data = resp.read()
                self.send_response(resp.status)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(data)))
                self._cors()
                self.end_headers()
                self.wfile.write(data)
                return

            # streaming: chunked passthrough
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Transfer-Encoding", "chunked")
            self._cors()
            self.end_headers()
            try:
                while True:
                    chunk = resp.read1(4096) if hasattr(resp, "read1") else resp.read(4096)
                    if not chunk:
                        break
                    self.wfile.write(b"%x\r\n" % len(chunk) + chunk + b"\r\n")
                    self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError):
                pass
            finally:
                try:
                    self.wfile.write(b"0\r\n\r\n")
                    self.wfile.flush()
                except Exception:  # noqa: BLE001
                    pass


def cmd_serve(args):
    global GH_TOKEN, _initiator_default
    registar_chaves(args.api_key)
    _initiator_default = args.initiator

    if args.upstream_base:
        # ---- modo genérico: não faz login GitHub ----
        UPSTREAM["base"] = args.upstream_base.rstrip("/")
        UPSTREAM["key"] = (
            args.upstream_key
            or os.environ.get("UPSTREAM_API_KEY")
            or os.environ.get("ZAI_API_KEY")
            or os.environ.get("OPENROUTER_API_KEY")
            or ""
        )
        UPSTREAM["model"] = args.upstream_model
        GH_TOKEN = None
        print(f"[+] modo genérico: upstream={UPSTREAM['base']}")
        print(f"    model={UPSTREAM['model'] or '(passthrough do cliente)'} key={'set' if UPSTREAM['key'] else 'AUSENTE'}")
    else:
        # ---- modo GitHub Copilot ----
        GH_TOKEN = ensure_gh_token()
        # pré-aquece o token para falhar cedo se a conta não tiver Copilot
        try:
            _, api = copilot_token(GH_TOKEN, force=True)
            print(f"[+] Token Copilot OK (api={api})")
        except Exception as e:  # noqa: BLE001
            raise SystemExit(f"[!] {e}")

    srv = ThreadingHTTPServer((args.host, args.port), Handler)
    p = args.port
    if args.host in ("0.0.0.0", "::", ""):
        print(f"[+] /v1 falso a ouvir em 0.0.0.0:{p} (todas as interfaces)")
        print(f"    mesmo PC:   http://127.0.0.1:{p}/v1")
        print(f"    Docker:     http://host.docker.internal:{p}/v1   <- usa ESTE no perfil do ARTEX")
        print(f"    outro PC:   http://<ip-desta-maquina>:{p}/v1")
        print("    (nunca ponhas 0.0.0.0 no perfil do ARTEX: é um endereço de escuta, não de destino)")
    else:
        print(f"[+] /v1 falso em http://{args.host}:{p}/v1")
        print(f"    ex.: OPENAI_BASE_URL=http://{args.host}:{p}/v1 OPENAI_API_KEY=dummy")
    print("    perfil ARTEX: Format=OpenAI (Chat Completions) · Model=gpt-6-luna")
    if LOCAL_API_KEYS:
        print(f"[+] auth local activa: {len(LOCAL_API_KEYS)} chave(s) aceite(s) — "
              "uma por modelo")
        for m, k in sorted(load_keys().items()):
            if k in LOCAL_API_KEYS:
                print(f"      {m:<28} {k}")
        print("    (gera/consulta com: python poc.py keys)")
    else:
        print("[i] sem --api-key: aceita qualquer Bearer (ex.: dummy)")
    print("    Ctrl+C para parar.")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n[!] a sair...")
    finally:
        srv.server_close()


LANDING = """<!doctype html>
<html lang="pt"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Copilot PoC · /v1</title>
<style>
 body{margin:0;background:#12131a;color:#e8e8ef;font:15px/1.6 system-ui,Segoe UI,Arial}
 .wrap{max-width:760px;margin:48px auto;padding:0 20px}
 h1{font-size:26px;margin:0 0 4px}
 .ok{color:#7ee2a8;font-weight:600;margin:0 0 24px}
 .bad{color:#ff8a8a}
 .card{background:#1b1d27;border:1px solid #2b2e3d;border-radius:12px;padding:18px 20px;margin:16px 0}
 table{border-collapse:collapse;width:100%}
 td{padding:6px 0;vertical-align:top}
 td:first-child{color:#9aa0b4;width:130px}
 code{background:#0e0f15;border:1px solid #2b2e3d;border-radius:6px;padding:2px 7px;color:#c9d1ff}
 a{color:#9db4ff}
 .note{color:#8b90a3;font-size:13px}
 .dot{display:inline-block;width:9px;height:9px;border-radius:50%;background:#7ee2a8;margin-right:7px}
</style></head><body><div class="wrap">
<h1>🐼 Copilot PoC</h1>
<p class="ok"><span class="dot"></span>online · OpenAI-compatible</p>
<div class="card">
<table>
<tr><td>Base URL</td><td><code>http://127.0.0.1:{{PORT}}/v1</code></td></tr>
<tr><td>Provider</td><td><code>openai</code></td></tr>
<tr><td>Modelo</td><td><code>gpt-6-luna</code> · confirma em <a href="/v1/models">/v1/models</a></td></tr>
<tr><td>API Key</td><td><code>dummy</code> (ou a definida em --api-key)</td></tr>
</table>
</div>
<div class="card">
<strong>Rotas</strong><p>
<a href="/v1/models">/v1/models</a> · /v1/chat/completions · /v1/responses · /health · <a href="/v1">/v1</a>
</p>
<strong>Teste rápido</strong>
<pre><code>curl http://127.0.0.1:{{PORT}}/v1/models</code></pre>
</div>
<p class="note">Esta é a API da PoC, não a UI do ARTEX. A UI do ARTEX corre na porta 8787 (ou na que configuraste).</p>
</div></body></html>"""


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
def main(argv=None):
    p = argparse.ArgumentParser(
        prog="poc.py",
        description="GitHub Copilot -> /v1 compatível com OpenAI (PoC).",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Exemplos:\n"
               "  python3 poc.py login\n"
               "  python3 poc.py whoami\n"
               "  python3 poc.py ask \"resume TCP e UDP\" -m gpt-4o\n"
               "  python3 poc.py serve --port 4141\n",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("login", help="device flow: autoriza e guarda o token GitHub")
    sub.add_parser("whoami", help="mostra plano e quota da conta")
    sub.add_parser("models", help="lista modelos disponíveis")
    sub.add_parser("keys", help="mostra/gera as chaves locais (uma por modelo)")

    a = sub.add_parser("ask", help="pergunta one-shot")
    a.add_argument("prompt")
    a.add_argument("-m", "--model", default="gpt-4o")
    a.add_argument("--no-stream", action="store_true", help="desliga streaming")

    s = sub.add_parser("serve", help="sobe o /v1 falso")
    s.add_argument("--host", default="127.0.0.1")
    s.add_argument("--port", type=int, default=4141)
    s.add_argument("--api-key", default=None,
                   help="uma ou mais chaves separadas por vírgula (exige Bearer local)")
    s.add_argument("--initiator", default="user", choices=["user", "agent"],
                   help="valor default do header X-Initiator")
    s.add_argument("--upstream-base", default=None,
                   help="provider OpenAI-compatible em vez do Copilot, ex.: "
                        "https://api.z.ai/api/paas/v4 | https://openrouter.ai/api/v1")
    s.add_argument("--upstream-key", default=None,
                   help="API key do upstream (ou env UPSTREAM_API_KEY/ZAI_API_KEY/OPENROUTER_API_KEY)")
    s.add_argument("--upstream-model", default=None,
                   help="força o model no body, ex.: glm-5.3-flash | z-ai/glm-5.3-flash")

    args = p.parse_args(argv)

    if args.cmd == "login":
        tok = device_login()
        save_gh_token(tok)
        print(f"[+] OK. Token guardado em {TOKEN_FILE}")
    elif args.cmd == "whoami":
        cmd_whoami()
    elif args.cmd == "models":
        cmd_models()
    elif args.cmd == "keys":
        cmd_keys()
    elif args.cmd == "ask":
        cmd_ask(args)
    elif args.cmd == "serve":
        cmd_serve(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
